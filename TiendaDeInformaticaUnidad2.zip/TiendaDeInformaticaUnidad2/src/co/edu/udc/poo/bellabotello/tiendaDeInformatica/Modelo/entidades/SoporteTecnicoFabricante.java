
package co.edu.udc.poo.bellabotello.tiendaDeInformatica.Modelo.entidades;


public class SoporteTecnicoFabricante {
    private String id;
    private String detalleSoporte;
    private double precioSoporte;
    private EmpresaFabricante empresa;
    private ProductoAltaTecnologia producto;

    public SoporteTecnicoFabricante(String id, String detalleSoporte, double precioSoporte, EmpresaFabricante empresa, ProductoAltaTecnologia producto) {
        this.id = id;
        this.detalleSoporte = detalleSoporte;
        this.precioSoporte = precioSoporte;
        this.empresa = empresa;
        this.producto = producto;
    }
    
    public String getIdSoporte() {
        return id;
    }
    
    public double getPrecioSoporte(){
        return precioSoporte;
    }
    
    public EmpresaFabricante getEmpresa(){
        return empresa;
    }
    
    public ProductoAltaTecnologia getProducto(){
        return producto;
    }
    
    public void setDetalleSoporte (String detalleSoporte){
        this.detalleSoporte = detalleSoporte;
    }
    
    public void setEmpresa (EmpresaFabricante empresa) {
        this.empresa = empresa;
    }
    
    public void mostrarInformacion(){
         System.out.printf("%-25s: $%.2f\n", "Precio del Soporte", precioSoporte);
         if (empresa != null) {
            System.out.printf("%-25s: %s\n", "Empresa Fabricante", empresa.getNombreFabricante());
        }else{
             System.out.println("Empresa Fabricante No especificada"); 
        }
         
        if (producto != null) {
            System.out.printf("%-25s: %s\n", "Producto Soportado", producto.getNumeroSerie());
        }else{
            System.out.println("Producto Soportado no especificado.");
        }
    
    }
    
}