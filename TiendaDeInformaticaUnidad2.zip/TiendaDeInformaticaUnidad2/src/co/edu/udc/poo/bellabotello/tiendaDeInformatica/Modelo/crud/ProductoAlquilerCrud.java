package co.edu.udc.poo.bellabotello.tiendaDeInformatica.Modelo.crud;

import co.edu.udc.poo.bellabotello.tiendaDeInformatica.Modelo.entidades.ProductoAlquiler; // Importa la clase
import java.util.ArrayList;
import java.util.List;

public class ProductoAlquilerCrud {

    private List<ProductoAlquiler> listaAlquileres;

    public ProductoAlquilerCrud() {
        this.listaAlquileres = new ArrayList<>();
    }

    // C - Create: Agregar un nuevo Producto en Alquiler
    public void agregar(ProductoAlquiler alquiler) throws Exception {
        if (alquiler == null) {
            throw new IllegalArgumentException("El producto en alquiler a agregar no puede ser nulo.");
        }
        // Verificamos si ya existe un alquiler con el mismo ID
        for (ProductoAlquiler pa : listaAlquileres) {
            if (pa.getIdAlquiler().equals(alquiler.getIdAlquiler())) {
                throw new Exception("Error: Ya existe un producto en alquiler con el ID '" + alquiler.getIdAlquiler() + "'.");
            }
        }
        listaAlquileres.add(alquiler);
        System.out.println("Producto en Alquiler con ID '" + alquiler.getIdAlquiler() + "' agregado exitosamente.");
    }

    // R - Read: Buscar un Producto en Alquiler por su ID
    public ProductoAlquiler buscar(String id) throws Exception {
        if (id == null || id.trim().isEmpty()) {
            throw new IllegalArgumentException("El ID de búsqueda no puede ser nulo o vacío.");
        }
        for (ProductoAlquiler pa : listaAlquileres) {
            if (pa.getIdAlquiler().equals(id)) {
                return pa;
            }
        }
        throw new Exception("Error: No se encontró ningún producto en alquiler con el ID '" + id + "'.");
    }

    // U - Update: Editar un Producto en Alquiler existente
    public void editar(ProductoAlquiler alquilerActualizado) throws Exception {
        if (alquilerActualizado == null) {
            throw new IllegalArgumentException("El producto en alquiler a actualizar no puede ser nulo.");
        }
        boolean encontrado = false;
        for (int i = 0; i < listaAlquileres.size(); i++) {
            if (listaAlquileres.get(i).getIdAlquiler().equals(alquilerActualizado.getIdAlquiler())) {
                // Actualiza el alquiler en la lista
                listaAlquileres.set(i, alquilerActualizado);
                encontrado = true;
                System.out.println("Producto en Alquiler con ID '" + alquilerActualizado.getIdAlquiler() + "' actualizado exitosamente.");
                break;
            }
        }
        if (!encontrado) {
            throw new Exception("Error: No se encontró un producto en alquiler con el ID '" + alquilerActualizado.getIdAlquiler() + "' para actualizar.");
        }
    }

    // D - Delete: Eliminar un Producto en Alquiler por su ID
    public void eliminar(String id) throws Exception {
        if (id == null || id.trim().isEmpty()) {
            throw new IllegalArgumentException("El ID de eliminación no puede ser nulo o vacío.");
        }
        ProductoAlquiler alquilerAEliminar = null;
        for (ProductoAlquiler pa : listaAlquileres) {
            if (pa.getIdAlquiler().equals(id)) {
                alquilerAEliminar = pa;
                break;
            }
        }

        if (alquilerAEliminar != null) {
            listaAlquileres.remove(alquilerAEliminar);
            System.out.println("Producto en Alquiler con ID '" + id + "' eliminado exitosamente. Nuevo número de alquileres: " + contar());
        } else {
            throw new Exception("Error: No se encontró ningún producto en alquiler con el ID '" + id + "' para eliminar.");
        }
    }

    // R - Read: Listar todos los Productos en Alquiler
    public ArrayList<ProductoAlquiler> listarTodo() throws Exception {
        if (listaAlquileres.isEmpty()) {
            throw new Exception("No hay Productos en Alquiler en la lista.");
        }
        return new ArrayList<>(listaAlquileres); // Retorna una copia
    }

    // Contar el número de Productos en Alquiler
    public Integer contar() {
        return listaAlquileres.size();
    }
}