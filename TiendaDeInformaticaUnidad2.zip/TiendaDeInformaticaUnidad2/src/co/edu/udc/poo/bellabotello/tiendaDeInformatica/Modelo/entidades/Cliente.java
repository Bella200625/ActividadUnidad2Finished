
package co.edu.udc.poo.bellabotello.tiendaDeInformatica.Modelo.entidades;


public class Cliente {
    private String codigoCliente;
    private String nombre;
    private String id;
    private String email;
    private String telefono;
    private String direccion;

    public Cliente(String codigoCliente, String nombre,String id, String email, String telefono, String direccion) {
        this.codigoCliente = codigoCliente;
        this.nombre = nombre;
        this.id = id;
        this.email = email;
        this.telefono = telefono;
        this.direccion = direccion;    
    }
    
    
    public String getCodigoCliente() {
        return codigoCliente;
    }

    public void setCodigoCliente(String idCliente) {
        this.codigoCliente = codigoCliente;
    }

    public String getNombre() {
        return nombre;
    }
    
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    
    public String getId() {
        return id = id;
    }
    
    public void setId(String id) {
        this.id = id;
    }
    
    public String getEmail() {
        return email;
    }
    
    public void setEmail(String email) {
        this.email = email;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public String getTelefono() {
        return telefono;
    }
    
    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }
    
    
     public void mostrarInformacion(){
     System.out.printf("%-25s: %s\n", "codigo Cliente", codigoCliente);
     System.out.printf("%-25s: %s\n", "Nombre del cliente", nombre);
     System.out.printf("%-25s: %s\n", "id", id);
     System.out.printf("%-25s: %s\n", "Correo", email);
     System.out.printf("%-25s: %s\n", "Telefono", telefono);
     System.out.printf("%-25s: %s\n", "Direccion", direccion);
     }
     
         @Override
    public boolean equals(Object o) {
        if (this == o) return true; // Si es la misma instancia
        if (o == null || getClass() != o.getClass()) return false; // Si es nulo o de diferente clase
        Cliente cliente = (Cliente) o; // Castea el objeto a Cliente
        return codigoCliente.equalsIgnoreCase(cliente.codigoCliente); // Compara por ID (ignora mayúsculas/minúsculas)
    }

    @Override
    public int hashCode() {
        return codigoCliente.toLowerCase().hashCode();
        
    }
     
}
