
package co.edu.udc.poo.bellabotello.tiendaDeInformatica.Modelo.entidades;


public class ClienteImpresora {
    private String codigoClienteImpresora;
    private String nombre;
    private String id;
    private String email;
    private String telefono;
    private String direccion;
    private Impresora impresora;

    public ClienteImpresora(String codigoCliente, String nombre, String id,String email, String telefono, String direccion, Impresora impresora) {
        this.codigoClienteImpresora = codigoCliente;
        this.nombre = nombre;
        this.id = id;
        this.email = email;
        this.telefono = telefono;
        this.direccion = direccion;
        this.impresora = impresora;      
       
    }
     
    public String getCodigoCliente(){
        return codigoClienteImpresora;
    }
    
    public String getId(){
        return id;
    }
    
    
     public void mostrarInformacion(){
     System.out.printf("%-25s: %s\n", "Codigo Cliente", codigoClienteImpresora);
     System.out.printf("%-25s: %s\n", "Nombre del cliente", nombre);
     System.out.printf("%-25s: %s\n", "ID", id);
     System.out.printf("%-25s: %s\n", "Correo", email);
     System.out.printf("%-25s: %s\n", "Telefono", telefono);
     System.out.printf("%-25s: %s\n", "Direccion", direccion);
     System.out.printf("%-25s: %s\n", "Codigo impresora", impresora.getCodigo());
     }
}
