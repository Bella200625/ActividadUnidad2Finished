package co.edu.udc.poo.bellabotello.tiendaDeInformatica.Modelo.crud;

import co.edu.udc.poo.bellabotello.tiendaDeInformatica.Modelo.entidades.Impresora; // Importa la clase Impresora
import java.util.ArrayList;
import java.util.List;

public class ImpresoraCrud {

    private List<Impresora> listaImpresoras; // La lista ahora es específicamente de objetos Impresora

    public ImpresoraCrud() {
        this.listaImpresoras = new ArrayList<>();
    }

    // C - Create: Agregar una nueva Impresora
    public void agregar(Impresora impresora) throws Exception {
        if (impresora == null) {
            throw new IllegalArgumentException("La impresora a agregar no puede ser nula.");
        }
        // Verificamos si ya existe una impresora con el mismo código
        for (Impresora imp : listaImpresoras) {
            if (imp.getCodigo().equals(impresora.getCodigo())) {
                throw new Exception("Error: Ya existe una impresora con el código '" + impresora.getCodigo() + "'.");
            }
        }
        listaImpresoras.add(impresora);
        System.out.println("=====================================================");
        System.out.println("Impresora con código '" + impresora.getCodigo() + "' agregada exitosamente.");
        System.out.println("=====================================================");
    }

    // R - Read: Buscar una Impresora por su código
    public Impresora buscar(String codigo) throws Exception { // El código de Impresora es String
        if (codigo == null || codigo.trim().isEmpty()) {
            throw new IllegalArgumentException("El código de búsqueda no puede ser nulo o vacío.");
        }
        for (Impresora imp : listaImpresoras) {
            if (imp.getCodigo().equals(codigo)) {
                return imp;
            }
        }
        throw new Exception("Error: No se encontró ninguna impresora con el código '" + codigo + "'.");
    }

    // U - Update: Editar una Impresora existente
    public void editar(Impresora impresoraActualizada) throws Exception {
        if (impresoraActualizada == null) {
            throw new IllegalArgumentException("La impresora a actualizar no puede ser nula.");
        }
        boolean encontrado = false;
        for (int i = 0; i < listaImpresoras.size(); i++) {
            if (listaImpresoras.get(i).getCodigo().equals(impresoraActualizada.getCodigo())) {
                // Actualiza la impresora en la lista
                listaImpresoras.set(i, impresoraActualizada);
                encontrado = true;
                System.out.println("=====================================================");
                System.out.println("Impresora con código '" + impresoraActualizada.getCodigo() + "' actualizada exitosamente.");
                System.out.println("=====================================================");
                break;
            }
        }
        if (!encontrado) {
            throw new Exception("Error: No se encontró una impresora con el código '" + impresoraActualizada.getCodigo() + "' para actualizar.");
        }
    }

    // D - Delete: Eliminar una Impresora por su código
    public void eliminar(String codigo) throws Exception { // El código de Impresora es String
        if (codigo == null || codigo.trim().isEmpty()) {
            throw new IllegalArgumentException("El código de eliminación no puede ser nulo o vacío.");
        }
        Impresora impresoraAEliminar = null;
        for (Impresora imp : listaImpresoras) {
            if (imp.getCodigo().equals(codigo)) {
                impresoraAEliminar = imp;
                break;
            }
        }

        if (impresoraAEliminar != null) {
            listaImpresoras.remove(impresoraAEliminar);
            System.out.println("=====================================================");
            System.out.println("Impresora con código '" + codigo + "' eliminada exitosamente. Nuevo número de Impresoras: " + contar());
            System.out.println("=====================================================");
        } else {
            throw new Exception("Error: No se encontró ninguna impresora con el código '" + codigo + "' para eliminar.");
        }
    }

    // R - Read: Listar todas las Impresoras
    public ArrayList<Impresora> listarTodo() throws Exception {
        if (listaImpresoras.isEmpty()) {
            throw new Exception("No hay Impresoras en la lista.");
        }
        return new ArrayList<>(listaImpresoras); // Retorna una copia
    }

    // Contar el número de Impresoras
    public Integer contar() {
        return listaImpresoras.size();
    }
}