package co.edu.udc.poo.bellabotello.tiendaDeInformatica.Modelo.crud;
import co.edu.udc.poo.bellabotello.tiendaDeInformatica.Modelo.entidades.CPU; // Importa la clase CPU
import java.util.ArrayList;
import java.util.List;
public class CPUCrud {
     private List<CPU> listaCPUs; // La lista ahora es específicamente de objetos CPU

    public CPUCrud() {
        this.listaCPUs = new ArrayList<>();
    }

    // C - Create: Agregar una nueva CPU
    public void agregar(CPU cpu) throws Exception {
        if (cpu == null) {
            throw new IllegalArgumentException("La CPU a agregar no puede ser nula.");
        }
        // Verificamos si ya existe una CPU con el mismo código
        for (CPU c : listaCPUs) {
            if (c.getCodigo().equals(cpu.getCodigo())) {
                throw new Exception("Error: Ya existe una CPU con el código '" + cpu.getCodigo() + "'.");
            }
        }
        listaCPUs.add(cpu);
        System.out.println("=====================================================");
        System.out.println("CPU con código '" + cpu.getCodigo() + "' agregada exitosamente.");
        System.out.println("=====================================================");
    }

    // R - Read: Buscar una CPU por su código
    public CPU buscar(String codigo) throws Exception { // El código de CPU es String
        if (codigo == null || codigo.trim().isEmpty()) {
            throw new IllegalArgumentException("El código de búsqueda no puede ser nulo o vacío.");
        }
        for (CPU c : listaCPUs) {
            if (c.getCodigo().equals(codigo)) {
                return c;
            }
        }
        throw new Exception("Error: No se encontró ninguna CPU con el código '" + codigo + "'.");
    }

    // U - Update: Editar una CPU existente
    public void editar(CPU cpuActualizada) throws Exception {
        if (cpuActualizada == null) {
            throw new IllegalArgumentException("La CPU a actualizar no puede ser nula.");
        }
        boolean encontrado = false;
        for (int i = 0; i < listaCPUs.size(); i++) {
            if (listaCPUs.get(i).getCodigo().equals(cpuActualizada.getCodigo())) {
                // Actualiza la CPU en la lista
                listaCPUs.set(i, cpuActualizada);
                encontrado = true;
                System.out.println("=====================================================");
                System.out.println("CPU con código '" + cpuActualizada.getCodigo() + "' actualizada exitosamente.");
                System.out.println("=====================================================");
                break;
            }
        }
        if (!encontrado) {
            throw new Exception("Error: No se encontró una CPU con el código '" + cpuActualizada.getCodigo() + "' para actualizar.");
        }
    }

    // D - Delete: Eliminar una CPU por su código
    public void eliminar(String codigo) throws Exception { // El código de CPU es String
        if (codigo == null || codigo.trim().isEmpty()) {
            throw new IllegalArgumentException("El código de eliminación no puede ser nulo o vacío.");
        }
        CPU cpuAEliminar = null;
        for (CPU c : listaCPUs) {
            if (c.getCodigo().equals(codigo)) {
                cpuAEliminar = c;
                break;
            }
        }

        if (cpuAEliminar != null) {
            listaCPUs.remove(cpuAEliminar);
            System.out.println("=====================================================");
            System.out.println("CPU con código '" + codigo + "' eliminada exitosamente. Nuevo número de CPUs: " + contar());
            System.out.println("=====================================================");
        } else {
            throw new Exception("Error: No se encontró ninguna CPU con el código '" + codigo + "' para eliminar.");
        }
    }

    // R - Read: Listar todas las CPUs
    public ArrayList<CPU> listarTodo() throws Exception {
        if (listaCPUs.isEmpty()) {
            throw new Exception("No hay CPUs en la lista.");
        }
        return new ArrayList<>(listaCPUs); // Retorna una copia
    }

    // Contar el número de CPUs
    public Integer contar() {
        return listaCPUs.size();
    }
    
    
}
