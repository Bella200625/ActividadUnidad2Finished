
package co.edu.udc.poo.bellabotello.tiendaDeInformatica.Modelo.entidades;


public class EmpresaFabricante {
    private String nombreFabricante;
    private String direccion;
    private int numEmpleados;
    private String paisOrigen;
    

    public EmpresaFabricante(String nombreFabricante, String direccion, String paisOrigen, int numEmpleados) {
        this.nombreFabricante = nombreFabricante;
        this.direccion = direccion;
        this.numEmpleados = numEmpleados;
        this.paisOrigen = paisOrigen;
    }
    
    
    
    public String getNombreFabricante() {
        return nombreFabricante;
    }
    
    public String getPaisOrigen() {
        return paisOrigen;
    }
    
    public void setNombreFabricante(String nombreFabricante) {
        this.nombreFabricante = nombreFabricante;
    }
    
    public void setDireccion(String direccion){
        this.direccion = direccion;
    }

    
    public void mostrarInformacion() {
        // System.out.printf("%-25s: %s\n", "")
        System.out.printf("%-25s: %s\n", "Nombre de la empresa", nombreFabricante);
        System.out.printf("%-25s: %s\n", "Direccion", direccion);
        System.out.printf("%-25s: %s\n", "Numero de empleados", numEmpleados);
        System.out.println("-----------------------------------------------------------");
    }
    
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        EmpresaFabricante that = (EmpresaFabricante) o;
        return nombreFabricante.equals(that.nombreFabricante);
    }

    @Override
    public int hashCode() {
        return nombreFabricante.hashCode();
    }
}
