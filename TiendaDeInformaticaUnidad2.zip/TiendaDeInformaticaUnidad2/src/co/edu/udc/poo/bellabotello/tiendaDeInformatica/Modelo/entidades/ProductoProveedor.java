
package co.edu.udc.poo.bellabotello.tiendaDeInformatica.Modelo.entidades;

import java.util.Date;

public class ProductoProveedor {
    private String id;
    private Date fechaAdquisicion;
    private Producto producto;
    private Proveedor proveedor;
    private int cantindadSuministrada;

    public ProductoProveedor(String id, Date fechaAdquisicion, Producto producto, Proveedor proveedor, int cantidadSuministrada) {
        this.id = id;
        this.fechaAdquisicion = fechaAdquisicion;
        this.producto = producto;
        this.proveedor = proveedor;
        this.cantindadSuministrada = cantidadSuministrada;
    }

    public void setCantidadSuministrada (int cantidadSuministrada) {
        this.cantindadSuministrada = cantidadSuministrada;
    }
    
    public void setFechaAdquisicion (Date fechaAdquisicion) {
        this.fechaAdquisicion = fechaAdquisicion;
    }
    
    public String getIdProductoProveedor() {
        return id;
    }
    
    public Date getFechaAdquisicion() {
        return fechaAdquisicion;
    }

    public Producto getProducto() {
        return producto;
    }

    public Proveedor getProveedor() {
        return proveedor;
    }
//Aqui se tuvo que utilizar instanceof, de producto a CPU, ya que en main
//Se esta llamando un producto desde la CLASE producto, y dicho producto sale
//de la clase CPU
    public void mostrarInformacion() {
        System.out.printf("%-25s: %s\n","Fecha de Adquisicion" , fechaAdquisicion);
        if (producto instanceof CPU) {
            CPU cpu = (CPU) producto;
            System.out.printf("%-25s: %s\n","Producto" , cpu.getModelo());
            System.out.printf("%-25s: %s\n","Codigo" , cpu.getCodigo());
        } else if (producto instanceof Impresora) {
            Impresora impresora = (Impresora) producto;
            System.out.printf("%-25s: %s\n","Producto" , impresora.getModelo());
            System.out.printf("%-25s: %s\n","Codigo" , impresora.getCodigo());
        } else if (producto instanceof Monitor) {
            Monitor monitor = (Monitor) producto;
            System.out.printf("%-25s: %s\n","Producto" , monitor.getModelo());
            System.out.printf("%-25s: %s\n","Codigo" , monitor.getCodigo());
        } else if (producto instanceof DiscoDuro) {
            DiscoDuro discoDuro = (DiscoDuro) producto;
            System.out.printf("%-25s: %s\n","Producto" , discoDuro.getModelo());
            System.out.printf("%-25s: %s\n","Codigo" , discoDuro.getCodigo());
        } else if (producto instanceof OtroProducto) {
            OtroProducto otroProducto = (OtroProducto) producto;
            System.out.printf("%-25s: %s\n","Producto" , otroProducto.getModelo());
            System.out.printf("%-25s: %s\n","Codigo" , otroProducto.getCodigo());
        } else {
            System.out.println("  Producto: " + producto.getModelo() + " (Codigo: " + producto.getCodigo() + ")");
        }
        System.out.println("  Proveedor: " + proveedor.getNIF());
    }
}