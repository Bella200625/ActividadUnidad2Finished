package co.edu.udc.poo.bellabotello.tiendaDeInformatica.Modelo.crud;


import java.util.ArrayList; 
import java.util.List;      

import co.edu.udc.poo.bellabotello.tiendaDeInformatica.Modelo.entidades.Cliente;

public class ClienteCrud {

    private List<Cliente> listaClientes; // Lista para almacenar los clientes

    // Constructor
    public ClienteCrud() {
        this.listaClientes = new ArrayList<>(); // Inicializa la lista
    }

    // C - Create: Agregar un nuevo Cliente a la lista
    public void agregar(Cliente cliente) throws Exception {
        if (cliente == null) {
            throw new IllegalArgumentException("El cliente a agregar no puede ser nulo.");
        }
        // Antes de agregar, verificar si ya existe un cliente con el mismo ID
        for (Cliente c : listaClientes) {
            // Utiliza equals() para comparar objetos, que internamente usa el idCliente
            if (c.equals(cliente)) { 
                throw new Exception("Error: Ya existe un cliente con el ID '" + cliente.getCodigoCliente() + "'.");
            }
        }
        listaClientes.add(cliente);
        System.out.println("=====================================================");
        System.out.println("Cliente con ID '" + cliente.getCodigoCliente() + "' agregado exitosamente.");
        System.out.println("=====================================================");
    }

    // R - Read: Buscar un Cliente por su ID
    public Cliente buscar(String idCliente) throws Exception {
        if (idCliente == null || idCliente.trim().isEmpty()) {
            throw new IllegalArgumentException("El ID de búsqueda del cliente no puede ser nulo o vacío.");
        }
        for (Cliente cliente : listaClientes) {
            // Compara el ID del cliente en la lista con el ID buscado
            if (cliente.getCodigoCliente().equalsIgnoreCase(idCliente)) { 
                return cliente; // Retorna el cliente encontrado
            }
        }
        throw new Exception("Error: No se encontró ningún cliente con el ID '" + idCliente + "'.");
    }

    // U - Update: Editar un Cliente existente en la lista
    public void editar(Cliente clienteActualizado) throws Exception {
        if (clienteActualizado == null) {
            throw new IllegalArgumentException("El cliente a actualizar no puede ser nulo.");
        }
        boolean encontrado = false;
        for (int i = 0; i < listaClientes.size(); i++) {
            // Encuentra el cliente por su ID y lo reemplaza
            if (listaClientes.get(i).getCodigoCliente().equalsIgnoreCase(clienteActualizado.getCodigoCliente())) {
                listaClientes.set(i, clienteActualizado); 
                encontrado = true;
                System.out.println("=====================================================");
                System.out.println("Cliente con ID '" + clienteActualizado.getCodigoCliente() + "' actualizado exitosamente.");
                System.out.println("=====================================================");
                break; 
            }
        }
        if (!encontrado) {
            throw new Exception("Error: No se encontró un cliente con el ID '" + clienteActualizado.getCodigoCliente() + "' para actualizar.");
        }
    }

    // D - Delete: Eliminar un Cliente de la lista por su ID
    public void eliminar(String idCliente) throws Exception {
        if (idCliente == null || idCliente.trim().isEmpty()) {
            throw new IllegalArgumentException("El ID de eliminación del cliente no puede ser nulo o vacío.");
        }
        Cliente clienteAEliminar = null;
        for (Cliente cliente : listaClientes) {
            if (cliente.getCodigoCliente().equalsIgnoreCase(idCliente)) {
                clienteAEliminar = cliente;
                break;
            }
        }

        if (clienteAEliminar != null) {
            listaClientes.remove(clienteAEliminar); // Utiliza el equals() del objeto Cliente
            System.out.println("=====================================================");
            System.out.println("Cliente con ID '" + idCliente + "' eliminado exitosamente. Nuevo número de clientes: " + contar());
            System.out.println("=====================================================");
        } else {
            throw new Exception("Error: No se encontró ningún cliente con el ID '" + idCliente + "' para eliminar.");
        }
    }

    // R - Read: Listar todos los Clientes en la lista
    public ArrayList<Cliente> listarTodo() throws Exception {
        if (listaClientes.isEmpty()) {
            throw new Exception("No hay clientes en la lista.");
        }
        return new ArrayList<>(listaClientes); // Retorna una copia para evitar modificaciones externas directas
    }

    // Contar el número de Clientes en la lista
    public Integer contar() {
        return listaClientes.size();
    }
}
