package co.edu.udc.poo.bellabotello.tiendaDeInformatica.Modelo.crud;

import co.edu.udc.poo.bellabotello.tiendaDeInformatica.Modelo.entidades.PrecioServicioTecnico; // Importa la clase
import java.util.ArrayList;
import java.util.List;

public class PrecioServicioTecnicoCrud {

    private List<PrecioServicioTecnico> listaPrecios;

    public PrecioServicioTecnicoCrud() {
        this.listaPrecios = new ArrayList<>();
    }

    // C - Create: Agregar un nuevo Precio de Servicio Técnico
    public void agregar(PrecioServicioTecnico precioST) throws Exception {
        if (precioST == null) {
            throw new IllegalArgumentException("El precio de servicio técnico a agregar no puede ser nulo.");
        }
        // Verificamos si ya existe un precio con el mismo ID
        for (PrecioServicioTecnico pst : listaPrecios) {
            if (pst.getIdPrecio().equals(precioST.getIdPrecio())) {
                throw new Exception("Error: Ya existe un precio de servicio técnico con el ID '" + precioST.getIdPrecio() + "'.");
            }
        }
        listaPrecios.add(precioST);
        System.out.println("Precio de Servicio Técnico con ID '" + precioST.getIdPrecio() + "' agregado exitosamente.");
    }

    // R - Read: Buscar un Precio de Servicio Técnico por su ID
    public PrecioServicioTecnico buscar(String id) throws Exception {
        if (id == null || id.trim().isEmpty()) {
            throw new IllegalArgumentException("El ID de búsqueda no puede ser nulo o vacío.");
        }
        for (PrecioServicioTecnico pst : listaPrecios) {
            if (pst.getIdPrecio().equals(id)) {
                return pst;
            }
        }
        throw new Exception("Error: No se encontró ningún precio de servicio técnico con el ID '" + id + "'.");
    }

    // U - Update: Editar un Precio de Servicio Técnico existente
    public void editar(PrecioServicioTecnico precioSTActualizado) throws Exception {
        if (precioSTActualizado == null) {
            throw new IllegalArgumentException("El precio de servicio técnico a actualizar no puede ser nulo.");
        }
        boolean encontrado = false;
        for (int i = 0; i < listaPrecios.size(); i++) {
            if (listaPrecios.get(i).getIdPrecio().equals(precioSTActualizado.getIdPrecio())) {
                // Actualiza el precio en la lista
                listaPrecios.set(i, precioSTActualizado);
                encontrado = true;
                System.out.println("Precio de Servicio Técnico con ID '" + precioSTActualizado.getIdPrecio() + "' actualizado exitosamente.");
                break;
            }
        }
        if (!encontrado) {
            throw new Exception("Error: No se encontró un precio de servicio técnico con el ID '" + precioSTActualizado.getIdPrecio() + "' para actualizar.");
        }
    }

    // D - Delete: Eliminar un Precio de Servicio Técnico por su ID
    public void eliminar(String id) throws Exception {
        if (id == null || id.trim().isEmpty()) {
            throw new IllegalArgumentException("El ID de eliminación no puede ser nulo o vacío.");
        }
        PrecioServicioTecnico precioSTAEliminar = null;
        for (PrecioServicioTecnico pst : listaPrecios) {
            if (pst.getIdPrecio().equals(id)) {
                precioSTAEliminar = pst;
                break;
            }
        }

        if (precioSTAEliminar != null) {
            listaPrecios.remove(precioSTAEliminar);
            System.out.println("Precio de Servicio Técnico con ID '" + id + "' eliminado exitosamente. Nuevo número de precios: " + contar());
        } else {
            throw new Exception("Error: No se encontró ningún precio de servicio técnico con el ID '" + id + "' para eliminar.");
        }
    }

    // R - Read: Listar todos los Precios de Servicio Técnico
    public ArrayList<PrecioServicioTecnico> listarTodo() throws Exception {
        if (listaPrecios.isEmpty()) {
            throw new Exception("No hay Precios de Servicio Técnico en la lista.");
        }
        return new ArrayList<>(listaPrecios); // Retorna una copia
    }

    // Contar el número de Precios de Servicio Técnico
    public Integer contar() {
        return listaPrecios.size();
    }
}