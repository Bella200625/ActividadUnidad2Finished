
package co.edu.udc.poo.bellabotello.tiendaDeInformatica.Modelo.crud;

import co.edu.udc.poo.bellabotello.tiendaDeInformatica.Modelo.entidades.Producto;
import java.util.ArrayList;
import java.util.List;

public class ProductoCrud {
    
    private List<Producto> listaProductos; //Usamos List para polimorfismo
    
    public ProductoCrud() {
        this.listaProductos = new ArrayList<>();
    }
    
    
    //C - Create: Agregar un nuevo producto
    public void agregar(Producto producto) throws Exception {
        if (producto == null) {
            throw new IllegalArgumentException("El producto a agregar no puede ser nulo");
        }
        
        //Verificamos si ya existe un producto con el mismo codigo
        for (Producto p : listaProductos) {
            if (p.getCodigo().equals(producto.getCodigo())) {
            throw new Exception("Error: Ya existe un producto con el codigo '" + producto.getCodigo() + "'.");
            }
        }
        listaProductos.add(producto);
        System.out.println("Producto con codigo '" + producto.getCodigo() + "' agregado exitosamente.");
    
            }
    
         // R - Read: Buscar un producto por su código
    public Producto buscar(String codigo) throws Exception { // Cambiamos a String ya que el código es String
        if (codigo == null || codigo.trim().isEmpty()) {
            throw new IllegalArgumentException("El código de búsqueda no puede ser nulo o vacío.");
        }
        for (Producto p : listaProductos) {
            if (p.getCodigo().equals(codigo)) {
                return p;
            }
        }
        throw new Exception("Error: No se encontró ningún producto con el código '" + codigo + "'.");
    }

    // U - Update: Editar un producto existente
    public void editar(Producto productoActualizado) throws Exception {
        if (productoActualizado == null) {
            throw new IllegalArgumentException("El producto a actualizar no puede ser nulo.");
        }
        boolean encontrado = false;
        for (int i = 0; i < listaProductos.size(); i++) {
            if (listaProductos.get(i).getCodigo().equals(productoActualizado.getCodigo())) {
                // Actualiza el producto en la lista
                listaProductos.set(i, productoActualizado);
                encontrado = true;
                System.out.println("Producto con código '" + productoActualizado.getCodigo() + "' actualizado exitosamente.");
                break;
            }
        }
        if (!encontrado) {
            throw new Exception("Error: No se encontró un producto con el código '" + productoActualizado.getCodigo() + "' para actualizar.");
        }
    }

    // D - Delete: Eliminar un producto por su código
    public void eliminar(String codigo) throws Exception { // Cambiamos a String
        if (codigo == null || codigo.trim().isEmpty()) {
            throw new IllegalArgumentException("El código de eliminación no puede ser nulo o vacío.");
        }
        Producto productoAEliminar = null;
        for (Producto p : listaProductos) {
            if (p.getCodigo().equals(codigo)) {
                productoAEliminar = p;
                break;
            }
        }

        if (productoAEliminar != null) {
            listaProductos.remove(productoAEliminar);
            System.out.println("Producto con código '" + codigo + "' eliminado exitosamente. Nuevo número de productos: " + contar());
        } else {
            throw new Exception("Error: No se encontró ningún producto con el código '" + codigo + "' para eliminar.");
        }
    }

    // R - Read: Listar todos los productos
    public ArrayList<Producto> listarTodo() throws Exception {
        if (listaProductos.isEmpty()) {
            throw new Exception("No hay productos en la lista.");
        }
        return new ArrayList<>(listaProductos); // Retorna una copia para evitar modificaciones externas
    }

    // Contar el número de productos
    public Integer contar() {
        return listaProductos.size();
    }
    
    
    
    
    
    
    
    
    
    
    
}
