
package co.edu.udc.poo.bellabotello.tiendaDeInformatica.Modelo.entidades;

public class DiscoDuro extends Producto {
    private String capacidadEspacio;
    private ProductoAltaTecnologia altaTecnologia;
    private ProductoAlquiler alquiler;

    public DiscoDuro(String codigo, String modelo, String capacidadEspacio) {
        super(codigo, modelo);
        this.capacidadEspacio = capacidadEspacio;
    }

    public void setAltaTecnologia(ProductoAltaTecnologia alta) {
        this.altaTecnologia = alta;
    }
    
    public void setCapacidadEspacio(String discoDuro) {
    this.capacidadEspacio = capacidadEspacio;
    }

    public void setAlquiler(ProductoAlquiler alquiler) {
        this.alquiler = alquiler;
    }

    @Override
    public void mostrarInformacion() {
        //System.out.printf("%-25s: %s\n", "")
        System.out.printf("%-25s: %s\n", "Codigo", super.getCodigo());
        System.out.printf("%-25s: %s\n", "Modelo", super.getModelo());
        System.out.printf("%-25s: %s\n", "Memoria Principal", capacidadEspacio);
        if (altaTecnologia != null) {
            System.out.println("---ES UN PRODUCTO DE ALTA TECNOLOGIA---.");
        System.out.printf("%-25s: %s\n", "Pais de origen", altaTecnologia.getPaisOrigen());
        System.out.printf("%-25s: %s\n", "Fecha de Fabricacion", altaTecnologia.getFechaFabricacion());
        System.out.printf("%-25s: %s\n", "Fabricante", altaTecnologia.getFabricante().getNombreFabricante());
        }else{
        System.out.println("---NO ES UN PRODUCTO DE ALTA TECNOLOGIA---");
        }
        if (alquiler != null) {
            System.out.println("---ESTE PRODUCTO SE PUEDE ALQUILAR---");
            System.out.printf("%-25s: %s\n", "Su Precio por Hora es de", alquiler.getPrecioHora());
        }else{
        System.out.println("---ESTE PRODUCTO NO SE PUEDE ALQUILAR---");
        }
    }
}
