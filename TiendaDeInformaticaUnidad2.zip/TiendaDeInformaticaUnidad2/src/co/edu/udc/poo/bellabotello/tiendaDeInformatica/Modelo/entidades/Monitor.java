
package co.edu.udc.poo.bellabotello.tiendaDeInformatica.Modelo.entidades;


public class Monitor extends Producto {
    private String resolucionMaxima;
    private ProductoAlquiler alquiler;
    
    public Monitor(String codigo, String modelo, String resolucionMaxima) {
        super(codigo, modelo);
        this.resolucionMaxima = resolucionMaxima;
    }
    
    public void setResolucionMaxima (String resolucionMaxima) {
        this.resolucionMaxima = resolucionMaxima;
    }
    
    public void setAlquiler(ProductoAlquiler alquiler) {
        this.alquiler = alquiler;
    }
    
    public ProductoAlquiler getAlquiler() {
        return alquiler;
}
    
    @Override
    public void mostrarInformacion() {
        // System.out.printf("%-25s: %s\n", "")
        System.out.printf("%-25s: %s\n", "Codigo: ", super.getCodigo());
        System.out.printf("%-25s: %s\n", "Modelo", super.getModelo());
        System.out.printf("%-25s: %s\n", "Relosucion Maxima", resolucionMaxima);
        if (alquiler != null) {
            System.out.println("---ESTE PRODUCTO SE PUEDE ALQUILAR---");
            System.out.printf("%-25s: %s\n", "Su Precio por Hora es de", alquiler.getPrecioHora());
        }else{
            System.out.println("---ESTE PRODUCTO NO SE PUEDE ALQUILAR---");
        }
    }
}
