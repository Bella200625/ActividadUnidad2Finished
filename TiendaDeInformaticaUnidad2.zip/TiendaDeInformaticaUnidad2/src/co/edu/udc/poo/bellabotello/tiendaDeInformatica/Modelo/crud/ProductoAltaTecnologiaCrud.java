package co.edu.udc.poo.bellabotello.tiendaDeInformatica.Modelo.crud;

import co.edu.udc.poo.bellabotello.tiendaDeInformatica.Modelo.entidades.ProductoAltaTecnologia; // Importa la clase
import java.util.ArrayList;
import java.util.List;

public class ProductoAltaTecnologiaCrud {

    private List<ProductoAltaTecnologia> listaProductosAltaTecnologia;

    public ProductoAltaTecnologiaCrud() {
        this.listaProductosAltaTecnologia = new ArrayList<>();
    }

    // C - Create: Agregar un nuevo Producto de Alta Tecnología
    public void agregar(ProductoAltaTecnologia productoAT) throws Exception {
        if (productoAT == null) {
            throw new IllegalArgumentException("El producto de alta tecnología a agregar no puede ser nulo.");
        }
        // Verificamos si ya existe un producto con el mismo número de serie
        for (ProductoAltaTecnologia pat : listaProductosAltaTecnologia) {
            // ===============================================================
            // CORRECCIÓN: usar equalsIgnoreCase para comparar Strings
            // ===============================================================
            if (pat.getNumeroSerie().equalsIgnoreCase(productoAT.getNumeroSerie())) {
                throw new Exception("Error: Ya existe un producto de alta tecnología con el número de serie '" + productoAT.getNumeroSerie() + "'.");
            }
        }
        listaProductosAltaTecnologia.add(productoAT);
        System.out.println("Producto de Alta Tecnología con número de serie '" + productoAT.getNumeroSerie() + "' agregado exitosamente.");
    }

    // R - Read: Buscar un Producto de Alta Tecnología por su número de serie
    public ProductoAltaTecnologia buscar(String numeroSerie) throws Exception {
        if (numeroSerie == null || numeroSerie.trim().isEmpty()) {
            throw new IllegalArgumentException("El número de serie de búsqueda no puede ser nulo o vacío.");
        }
        for (ProductoAltaTecnologia pat : listaProductosAltaTecnologia) {
            // ===============================================================
            // CORRECCIÓN: usar equalsIgnoreCase para comparar Strings
            // ===============================================================
            if (pat.getNumeroSerie().equalsIgnoreCase(numeroSerie)) {
                return pat;
            }
        }
        throw new Exception("Error: No se encontró ningún producto de alta tecnología con el número de serie '" + numeroSerie + "'.");
    }

    // U - Update: Editar un Producto de Alta Tecnología existente
    public void editar(ProductoAltaTecnologia productoATActualizado) throws Exception {
        if (productoATActualizado == null) {
            throw new IllegalArgumentException("El producto de alta tecnología a actualizar no puede ser nulo.");
        }
        boolean encontrado = false;
        for (int i = 0; i < listaProductosAltaTecnologia.size(); i++) {
            if (listaProductosAltaTecnologia.get(i).getNumeroSerie().equalsIgnoreCase(productoATActualizado.getNumeroSerie())) {
                listaProductosAltaTecnologia.set(i, productoATActualizado);
                encontrado = true;
                System.out.println("Producto de Alta Tecnología con número de serie '" + productoATActualizado.getNumeroSerie() + "' actualizado exitosamente.");
                break;
            }
        }
        if (!encontrado) {
            throw new Exception("Error: No se encontró un producto de alta tecnología con el número de serie '" + productoATActualizado.getNumeroSerie() + "' para actualizar.");
        }
    }

    // D - Delete: Eliminar un Producto de Alta Tecnología por su número de serie
    public void eliminar(String numeroSerie) throws Exception {
        if (numeroSerie == null || numeroSerie.trim().isEmpty()) {
            throw new IllegalArgumentException("El número de serie de eliminación no puede ser nulo o vacío.");
        }
        ProductoAltaTecnologia productoATAEliminar = null;
        for (ProductoAltaTecnologia pat : listaProductosAltaTecnologia) {
            // ===============================================================
            // CORRECCIÓN: usar equalsIgnoreCase para comparar Strings
            // ===============================================================
            if (pat.getNumeroSerie().equalsIgnoreCase(numeroSerie)) {
                productoATAEliminar = pat;
                break;
            }
        }

        if (productoATAEliminar != null) {
            listaProductosAltaTecnologia.remove(productoATAEliminar);
            System.out.println("Producto de Alta Tecnología con número de serie '" + numeroSerie + "' eliminado exitosamente. Nuevo número de productos: " + contar());
        } else {
            throw new Exception("Error: No se encontró ningún producto de alta tecnología con el número de serie '" + numeroSerie + "' para eliminar.");
        }
    }

    // R - Read: Listar todos los Productos de Alta Tecnología
    public ArrayList<ProductoAltaTecnologia> listarTodo() throws Exception {
        if (listaProductosAltaTecnologia.isEmpty()) {
            throw new Exception("No hay Productos de Alta Tecnología en la lista.");
        }
        return new ArrayList<>(listaProductosAltaTecnologia); // Retorna una copia
    }

    // Contar el número de Productos de Alta Tecnología
    public Integer contar() {
        return listaProductosAltaTecnologia.size();
    }
}





//package co.edu.udc.poo.bellabotello.tiendaDeInformatica.Modelo.crud;
//
//import co.edu.udc.poo.bellabotello.tiendaDeInformatica.Modelo.entidades.ProductoAltaTecnologia; // Importa la clase
//import java.util.ArrayList;
//import java.util.List;
//
//public class ProductoAltaTecnologiaCrud {
//
//    private List<ProductoAltaTecnologia> listaProductosAltaTecnologia;
//
//    public ProductoAltaTecnologiaCrud() {
//        this.listaProductosAltaTecnologia = new ArrayList<>();
//    }
//
//    // C - Create: Agregar un nuevo Producto de Alta Tecnología
//    public void agregar(ProductoAltaTecnologia productoAT) throws Exception {
//        if (productoAT == null) {
//            throw new IllegalArgumentException("El producto de alta tecnología a agregar no puede ser nulo.");
//        }
//        // Verificamos si ya existe un producto con el mismo número de serie
//        for (ProductoAltaTecnologia pat : listaProductosAltaTecnologia) {
//            if (pat.getNumeroSerie().equals(productoAT.getNumeroSerie())) {
//                throw new Exception("Error: Ya existe un producto de alta tecnología con el número de serie '" + productoAT.getNumeroSerie() + "'.");
//            }
//        }
//        listaProductosAltaTecnologia.add(productoAT);
//        System.out.println("Producto de Alta Tecnología con número de serie '" + productoAT.getNumeroSerie() + "' agregado exitosamente.");
//    }
//
//    // R - Read: Buscar un Producto de Alta Tecnología por su número de serie
//    public ProductoAltaTecnologia buscar(String numeroSerie) throws Exception {
//        if (numeroSerie == null || numeroSerie.trim().isEmpty()) {
//            throw new IllegalArgumentException("El número de serie de búsqueda no puede ser nulo o vacío.");
//        }
//        for (ProductoAltaTecnologia pat : listaProductosAltaTecnologia) {
//            if (pat.getNumeroSerie().equalsIgnoreCase(numeroSerie)) {
//                return pat;
//            }
//        }
//        throw new Exception("Error: No se encontró ningún producto de alta tecnología con el número de serie '" + numeroSerie + "'.");
//    }
//
//    // U - Update: Editar un Producto de Alta Tecnología existente
//    public void editar(ProductoAltaTecnologia productoATActualizado) throws Exception {
//        if (productoATActualizado == null) {
//            throw new IllegalArgumentException("El producto de alta tecnología a actualizar no puede ser nulo.");
//        }
//        boolean encontrado = false;
//        for (int i = 0; i < listaProductosAltaTecnologia.size(); i++) {
//            if (listaProductosAltaTecnologia.get(i).getNumeroSerie().equals(productoATActualizado.getNumeroSerie())) {
//                // Actualiza el producto en la lista
//                listaProductosAltaTecnologia.set(i, productoATActualizado);
//                encontrado = true;
//                System.out.println("Producto de Alta Tecnología con número de serie '" + productoATActualizado.getNumeroSerie() + "' actualizado exitosamente.");
//                break;
//            }
//        }
//        if (!encontrado) {
//            throw new Exception("Error: No se encontró un producto de alta tecnología con el número de serie '" + productoATActualizado.getNumeroSerie() + "' para actualizar.");
//        }
//    }
//
//    // D - Delete: Eliminar un Producto de Alta Tecnología por su número de serie
//    public void eliminar(String numeroSerie) throws Exception {
//        if (numeroSerie == null || numeroSerie.trim().isEmpty()) {
//            throw new IllegalArgumentException("El número de serie de eliminación no puede ser nulo o vacío.");
//        }
//        ProductoAltaTecnologia productoATAEliminar = null;
//        for (ProductoAltaTecnologia pat : listaProductosAltaTecnologia) {
//            if (pat.getNumeroSerie().equalsIgnoreCase(numeroSerie)) {
//                productoATAEliminar = pat;
//                break;
//            }
//        }
//
//        if (productoATAEliminar != null) {
//            listaProductosAltaTecnologia.remove(productoATAEliminar);
//            System.out.println("Producto de Alta Tecnología con número de serie '" + numeroSerie + "' eliminado exitosamente. Nuevo número de productos: " + contar());
//        } else {
//            throw new Exception("Error: No se encontró ningún producto de alta tecnología con el número de serie '" + numeroSerie + "' para eliminar.");
//        }
//    }
//
//    // R - Read: Listar todos los Productos de Alta Tecnología
//    public ArrayList<ProductoAltaTecnologia> listarTodo() throws Exception {
//        if (listaProductosAltaTecnologia.isEmpty()) {
//            throw new Exception("No hay Productos de Alta Tecnología en la lista.");
//        }
//        return new ArrayList<>(listaProductosAltaTecnologia); // Retorna una copia
//    }
//
//    // Contar el número de Productos de Alta Tecnología
//    public Integer contar() {
//        return listaProductosAltaTecnologia.size();
//    }
//}