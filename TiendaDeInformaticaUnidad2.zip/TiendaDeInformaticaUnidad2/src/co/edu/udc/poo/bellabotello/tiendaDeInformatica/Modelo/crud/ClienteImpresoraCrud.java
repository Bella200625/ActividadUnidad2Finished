package co.edu.udc.poo.bellabotello.tiendaDeInformatica.Modelo.crud;

import co.edu.udc.poo.bellabotello.tiendaDeInformatica.Modelo.entidades.ClienteImpresora; // Importa la clase ClienteImpresora
import java.util.ArrayList;
import java.util.List;

public class ClienteImpresoraCrud {

    private List<ClienteImpresora> listaClientes;

    public ClienteImpresoraCrud() {
        this.listaClientes = new ArrayList<>();
    }

    // C - Create: Agregar un nuevo cliente
    public void agregar(ClienteImpresora cliente) throws Exception {
        if (cliente == null) {
            throw new IllegalArgumentException("El cliente a agregar no puede ser nulo.");
        }
        // Verificamos si ya existe un cliente con el mismo código
        for (ClienteImpresora c : listaClientes) {
            if (c.getCodigoCliente().equals(cliente.getCodigoCliente())) {
                throw new Exception("Error: Ya existe un cliente con el código '" + cliente.getCodigoCliente() + "'.");
            }
        }
        listaClientes.add(cliente);
        System.out.println("=====================================================");
        System.out.println("Cliente con código '" + cliente.getCodigoCliente() + "' gregado exitosamente.");
        System.out.println("=====================================================");
    }

    // R - Read: Buscar un cliente por su código
    public ClienteImpresora buscar(String codigo) throws Exception {
        if (codigo == null || codigo.trim().isEmpty()) {
            throw new IllegalArgumentException("El código de búsqueda no puede ser nulo o vacío.");
        }
        for (ClienteImpresora c : listaClientes) {
            if (c.getCodigoCliente().equals(codigo)) {
                return c;
            }
        }
        throw new Exception("Error: No se encontró ningún cliente con el código '" + codigo + "'.");
    }

    // U - Update: Editar un cliente existente
    public void editar(ClienteImpresora clienteActualizado) throws Exception {
        if (clienteActualizado == null) {
            throw new IllegalArgumentException("El cliente a actualizar no puede ser nulo.");
        }
        boolean encontrado = false;
        for (int i = 0; i < listaClientes.size(); i++) {
            if (listaClientes.get(i).getCodigoCliente().equals(clienteActualizado.getCodigoCliente())) {
                // Actualiza el cliente en la lista
                listaClientes.set(i, clienteActualizado);
                encontrado = true;
                System.out.println("=====================================================");
                System.out.println("Cliente con código '" + clienteActualizado.getCodigoCliente() + "' actualizado exitosamente.");
                System.out.println("=====================================================");
                break;
            }
        }
        if (!encontrado) {
            throw new Exception("Error: No se encontró un cliente con el código '" + clienteActualizado.getCodigoCliente() + "' para actualizar.");
        }
    }

    // D - Delete: Eliminar un cliente por su código
    public void eliminar(String codigo) throws Exception {
        if (codigo == null || codigo.trim().isEmpty()) {
            throw new IllegalArgumentException("El código de eliminación no puede ser nulo o vacío.");
        }
        ClienteImpresora clienteAEliminar = null;
        for (ClienteImpresora c : listaClientes) {
            if (c.getCodigoCliente().equals(codigo)) {
                clienteAEliminar = c;
                break;
            }
        }

        if (clienteAEliminar != null) {
            listaClientes.remove(clienteAEliminar);
            System.out.println("=====================================================");
            System.out.println("Cliente con código '" + codigo + "' eliminado exitosamente. \nNuevo número de clientes: " + contar());
            System.out.println("=====================================================");
        } else {
            throw new Exception("Error: No se encontró ningún cliente con el código '" + codigo + "' para eliminar.");
        }
    }

    // R - Read: Listar todos los clientes
    public ArrayList<ClienteImpresora> listarTodo() throws Exception {
        if (listaClientes.isEmpty()) {
            throw new Exception("No hay clientes en la lista.");
        }
        return new ArrayList<>(listaClientes); // Retorna una copia
    }

    // Contar el número de clientes
    public Integer contar() {
        return listaClientes.size();
    }
}