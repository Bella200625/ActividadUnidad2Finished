package co.edu.udc.poo.bellabotello.tiendaDeInformatica.Modelo.crud;

import co.edu.udc.poo.bellabotello.tiendaDeInformatica.Modelo.entidades.Proveedor; // Importa la clase Proveedor
import java.util.ArrayList;
import java.util.List;

public class ProveedorCrud {

    private List<Proveedor> listaProveedores;

    public ProveedorCrud() {
        this.listaProveedores = new ArrayList<>();
    }

    // C - Create: Agregar un nuevo Proveedor
    public void agregar(Proveedor proveedor) throws Exception {
        if (proveedor == null) {
            throw new IllegalArgumentException("El proveedor a agregar no puede ser nulo.");
        }
        // Verificamos si ya existe un proveedor con el mismo nombre (ignorando mayúsculas/minúsculas)
        for (Proveedor prov : listaProveedores) {
            if (prov.getNombreProveedor().equalsIgnoreCase(proveedor.getNombreProveedor())) {
                throw new Exception("Error: Ya existe un proveedor con el nombre '" + proveedor.getNombreProveedor() + "'.");
            }
        }
        listaProveedores.add(proveedor);
        System.out.println("Proveedor '" + proveedor.getNombreProveedor() + "' agregado exitosamente.");
    }

    // R - Read: Buscar un Proveedor por su nombre
    public Proveedor buscar(String nombre) throws Exception {
        if (nombre == null || nombre.trim().isEmpty()) {
            throw new IllegalArgumentException("El nombre de búsqueda no puede ser nulo o vacío.");
        }
        for (Proveedor prov : listaProveedores) {
            if (prov.getNombreProveedor().equalsIgnoreCase(nombre)) {
                return prov;
            }
        }
        throw new Exception("Error: No se encontró ningún proveedor con el nombre '" + nombre + "'.");
    }

    // U - Update: Editar un Proveedor existente
    public void editar(Proveedor proveedorActualizado) throws Exception {
        if (proveedorActualizado == null) {
            throw new IllegalArgumentException("El proveedor a actualizar no puede ser nulo.");
        }
        boolean encontrado = false;
        for (int i = 0; i < listaProveedores.size(); i++) {
            // Buscamos por el nombre original del proveedor a actualizar
            if (listaProveedores.get(i).getNombreProveedor().equalsIgnoreCase(proveedorActualizado.getNombreProveedor())) {
                listaProveedores.set(i, proveedorActualizado);
                encontrado = true;
                System.out.println("Proveedor '" + proveedorActualizado.getNombreProveedor() + "' actualizado exitosamente.");
                break;
            }
        }
        if (!encontrado) {
            throw new Exception("Error: No se encontró un proveedor con el nombre '" + proveedorActualizado.getNombreProveedor() + "' para actualizar.");
        }
    }

    // D - Delete: Eliminar un Proveedor por su nombre
    public void eliminar(String nombre) throws Exception {
        if (nombre == null || nombre.trim().isEmpty()) {
            throw new IllegalArgumentException("El nombre de eliminación no puede ser nulo o vacío.");
        }
        Proveedor proveedorAEliminar = null;
        for (Proveedor prov : listaProveedores) {
            if (prov.getNombreProveedor().equalsIgnoreCase(nombre)) {
                proveedorAEliminar = prov;
                break;
            }
        }

        if (proveedorAEliminar != null) {
            listaProveedores.remove(proveedorAEliminar);
            System.out.println("Proveedor '" + nombre + "' eliminado exitosamente. Nuevo número de proveedores: " + contar());
        } else {
            throw new Exception("Error: No se encontró ningún proveedor con el nombre '" + nombre + "' para eliminar.");
        }
    }

    // R - Read: Listar todos los Proveedores
    public ArrayList<Proveedor> listarTodo() throws Exception {
        if (listaProveedores.isEmpty()) {
            throw new Exception("No hay Proveedores en la lista.");
        }
        return new ArrayList<>(listaProveedores); // Retorna una copia
    }

    // Contar el número de Proveedores
    public Integer contar() {
        return listaProveedores.size();
    }
}