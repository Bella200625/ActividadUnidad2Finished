package co.edu.udc.poo.bellabotello.tiendaDeInformatica.Modelo.entidades;

//Decimos que la Clase CPU es una subclase de Producto
 public class CPU extends Producto {
    //El atributo que tiene CPU, que es memoria principal
    private String memoriaPrincipal;
    //creamos un atributo para poder tener una variable que nos vincule a la clase ProductoAltaTecnologia
    private ProductoAltaTecnologia altaTecnologia;
    
    //Constructor de la Clase
    public CPU(String codigo, String modelo, String memoriaPrincipal) {
        //Usamos Super para tomar atributos de la clase PRODUCTO
        super(codigo, modelo);
        this.memoriaPrincipal = memoriaPrincipal;
    }
    
    //Declaramos que podemos usar informacion de la clase ProductoAltaTecnologia
//    public void setAltaTecnologia(ProductoAltaTecnologia ProductoAltaTecnologia) {
//        
//        //Decimos que declaramos una variable para poder llamar atributos de la clase ProductoAltaTecnologia
//        this.altaTecnologia = ProductoAltaTecnologia;
//    }
//    //Lo que obtenga de productoAltaTecnologia por medio del metodo getAltaTecnologia
//    //sera guardado en altaTecnologia
//    public ProductoAltaTecnologia getAltaTecnologia() {
//        return altaTecnologia;
//    }
    
    public void setMemoriaPrincipal(String memoriaPrincipal){
        this.memoriaPrincipal = memoriaPrincipal;
    }
    //Utilizamos override ya que utilizaremos atributos de la clase que esta heredando, osea PRODUCTO
    @Override
    public void mostrarInformacion() {
        //System.out.printf("%-25s: %s\n", "");
        //Se utiliza Prinf, para darle diseño a la hora de la salida de los datos
        //lo que hace este formato prinf es poder alinear la informacion que esta despues de la coma, "%-25s" son macardores de posicion
        //que alinea a la izquierda 25 caracteres, y este termina con :, para que al final de los espacios asignados se le agregue,
        //por ultimo el %s, siginifica que lo que se va a imprimit en este caso los metodos, sean en String.
        
        //Cuando queremos llamar un atributo de de la clase que nos hereda, utilizamos SUPER y get
        //hay que tener en cuenta que la clase producto nos de permiso creando los get
        
        System.out.println("------------------------------------------------");
        System.out.printf("%-25s: %s\n", "Codigo", super.getCodigo());
        System.out.printf("%-25s: %s\n", "Modelo", super.getModelo());
        
        
        //Utilizmaos la variable que esta en la clase normalmente.
        
        
        System.out.printf("%-25s: %s\n", "Memoria Principal", memoriaPrincipal);
        
        
        //Utilizamos If para decir que un producto puede ser de alta tecnologia o no
        
        
//    if (altaTecnologia != null) {
//        
//        
//        //si lo es, nos mostrara un mensaje diciendolo
//        
//        System.out.println("---ES UN PRODUCTO DE ALTA TECNOLOGIA---.");
//        //Cojemos el atributo de la clase ProductoAltaTecnologia > PaisOrigen, por medio de get y utilizando la variable que
//        //asignamos para entrar
//        System.out.printf("%-25s: %s\n", "Pais de origen", altaTecnologia.getPaisOrigen());
//        //Llamaos otro atributo de la clase ProductoAltaTecnologia > FechaFabricacion
//        System.out.printf("%-25s: %s\n", "Fecha de Fabricacion", altaTecnologia.getFechaFabricacion());
//        //Llamamos desde la clase ProductoAltaTecnologia que nos llame desde otra clase EmpresaFabricante, el nombre
//        //de la empresa CPU > ProductoAltaTecnologia > EmpresaFabricante > "nombre"
//        System.out.printf("%-25s: %s\n", "Fabricante", altaTecnologia.getFabricante().getNombreFabricante());
//        
//        //si no se asigna el objeto como alta tecnologia, nos saldra un mensaje diciendolo.
//    }else{
//        System.out.println("---NO ES UN PRODUCTO DE ALTA TECNOLOGIA---");
//    }
    }
}
