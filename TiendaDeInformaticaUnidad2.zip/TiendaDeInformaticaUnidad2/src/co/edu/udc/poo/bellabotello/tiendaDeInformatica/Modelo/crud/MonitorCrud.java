package co.edu.udc.poo.bellabotello.tiendaDeInformatica.Modelo.crud;

import co.edu.udc.poo.bellabotello.tiendaDeInformatica.Modelo.entidades.Monitor; // Importa la clase Monitor
import java.util.ArrayList;
import java.util.List;

public class MonitorCrud {

    private List<Monitor> listaMonitores; // La lista ahora es específicamente de objetos Monitor

    public MonitorCrud() {
        this.listaMonitores = new ArrayList<>();
    }

    // C - Create: Agregar un nuevo Monitor
    public void agregar(Monitor monitor) throws Exception {
        if (monitor == null) {
            throw new IllegalArgumentException("El monitor a agregar no puede ser nulo.");
        }
        // Verificamos si ya existe un monitor con el mismo código
        for (Monitor mon : listaMonitores) {
            if (mon.getCodigo().equals(monitor.getCodigo())) {
                throw new Exception("Error: Ya existe un monitor con el código '" + monitor.getCodigo() + "'.");
            }
        }
        listaMonitores.add(monitor);
        System.out.println("=====================================================");
        System.out.println("Monitor con código '" + monitor.getCodigo() + "' agregado exitosamente.");
        System.out.println("=====================================================");
    }

    // R - Read: Buscar un Monitor por su código
    public Monitor buscar(String codigo) throws Exception { // El código de Monitor es String
        if (codigo == null || codigo.trim().isEmpty()) {
            throw new IllegalArgumentException("El código de búsqueda no puede ser nulo o vacío.");
        }
        for (Monitor mon : listaMonitores) {
            if (mon.getCodigo().equals(codigo)) {
                return mon;
            }
        }
        throw new Exception("Error: No se encontró ningún monitor con el código '" + codigo + "'.");
    }

    // U - Update: Editar un Monitor existente
    public void editar(Monitor monitorActualizado) throws Exception {
        if (monitorActualizado == null) {
            throw new IllegalArgumentException("El monitor a actualizar no puede ser nulo.");
        }
        boolean encontrado = false;
        for (int i = 0; i < listaMonitores.size(); i++) {
            if (listaMonitores.get(i).getCodigo().equals(monitorActualizado.getCodigo())) {
                // Actualiza el monitor en la lista
                listaMonitores.set(i, monitorActualizado);
                encontrado = true;
                System.out.println("=====================================================");
                System.out.println("Monitor con código '" + monitorActualizado.getCodigo() + "' actualizado exitosamente.");
                System.out.println("=====================================================");
                break;
            }
        }
        if (!encontrado) {
            throw new Exception("Error: No se encontró un monitor con el código '" + monitorActualizado.getCodigo() + "' para actualizar.");
        }
    }

    // D - Delete: Eliminar un Monitor por su código
    public void eliminar(String codigo) throws Exception { // El código de Monitor es String
        if (codigo == null || codigo.trim().isEmpty()) {
            throw new IllegalArgumentException("El código de eliminación no puede ser nulo o vacío.");
        }
        Monitor monitorAEliminar = null;
        for (Monitor mon : listaMonitores) {
            if (mon.getCodigo().equals(codigo)) {
                monitorAEliminar = mon;
                break;
            }
        }

        if (monitorAEliminar != null) {
            listaMonitores.remove(monitorAEliminar);
            System.out.println("=====================================================");
            System.out.println("Monitor con código '" + codigo + "' eliminado exitosamente. Nuevo número de Monitores: " + contar());
            System.out.println("=====================================================");
        } else {
            throw new Exception("Error: No se encontró ningún monitor con el código '" + codigo + "' para eliminar.");
        }
    }

    // R - Read: Listar todos los Monitores
    public ArrayList<Monitor> listarTodo() throws Exception {
        if (listaMonitores.isEmpty()) {
            throw new Exception("No hay Monitores en la lista.");
        }
        return new ArrayList<>(listaMonitores); // Retorna una copia
    }

    // Contar el número de Monitores
    public Integer contar() {
        return listaMonitores.size();
    }
}