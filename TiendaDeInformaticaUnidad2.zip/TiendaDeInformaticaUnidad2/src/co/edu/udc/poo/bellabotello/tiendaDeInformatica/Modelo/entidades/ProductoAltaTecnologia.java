
package co.edu.udc.poo.bellabotello.tiendaDeInformatica.Modelo.entidades;

import java.util.Date;


public class ProductoAltaTecnologia {
    private Producto producto;
    private String numeroSerie;
    private String paisOrigen;
    private Date fechaFabricacion;
    private EmpresaFabricante fabricante;
 //   private Producto productoAsociado;

public ProductoAltaTecnologia(Producto producto, String numeroSerie, String paisOrigen, Date fechaFabricacion, EmpresaFabricante fabricante) {
    this.producto = producto;
    this.numeroSerie = numeroSerie;
    this.paisOrigen = paisOrigen;
    this.fechaFabricacion = fechaFabricacion;
    this.fabricante = fabricante;
  //  this.productoAsociado = productoAsociado;
}    


public void setProducto(Producto producto) {
    this.producto = producto;
}

public Producto getProducto(){
    return producto;
}

public void setFabricante(EmpresaFabricante fabricante){
    this.fabricante = fabricante;
}

public String getNumeroSerie() {
    return numeroSerie;
}

public void setNumeroSerie(String numeroSerie){
    this.numeroSerie = numeroSerie;
}

public String getPaisOrigen() {
    return paisOrigen;
}

public void setPaisOrigen(String paisOrigen){
    this.paisOrigen = paisOrigen;
}
public Date getFechaFabricacion() {
    return fechaFabricacion;
}

public void setFechaFabricacion(Date fechaFabricacion){
    this.fechaFabricacion = fechaFabricacion;
}
public EmpresaFabricante getFabricante() {
    return fabricante;
}
//public Producto getProductoAsociado() {
//    return productoAsociado;
//}


    public void mostrarInformacion (){
        System.out.printf("%-25s: %s\n", "Codigo Producto", producto.getCodigo());
        System.out.printf("%-25s: %s\n", "Numero de Serie", numeroSerie);
        System.out.printf("%-25s: %s\n", "pais de Origen", paisOrigen);
        System.out.printf("%-25s: %s\n", "Fecha de Fabricacion", fechaFabricacion);
        System.out.printf("%-25s: %s\n", "Empresa Fabricante", fabricante.getNombreFabricante());
    }
 
@Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ProductoAltaTecnologia that = (ProductoAltaTecnologia) o;
        return numeroSerie.equals(that.numeroSerie);
    }

    @Override
    public int hashCode() {
        return numeroSerie.hashCode();
    }

}
