package co.edu.udc.poo.bellabotello.tiendaDeInformatica.Modelo.crud;

import co.edu.udc.poo.bellabotello.tiendaDeInformatica.Modelo.entidades.EmpresaFabricante; // Importa la clase EmpresaFabricante
import java.util.ArrayList;
import java.util.List;

public class EmpresaFabricanteCrud {

    private List<EmpresaFabricante> listaFabricantes;

    public EmpresaFabricanteCrud() {
        this.listaFabricantes = new ArrayList<>();
    }

    // C - Create: Agregar una nueva Empresa Fabricante
    public void agregar(EmpresaFabricante fabricante) throws Exception {
        if (fabricante == null) {
            throw new IllegalArgumentException("La empresa fabricante a agregar no puede ser nula.");
        }
        // Verificamos si ya existe una empresa con el mismo nombre
        for (EmpresaFabricante ef : listaFabricantes) {
            if (ef.getNombreFabricante().equalsIgnoreCase(fabricante.getNombreFabricante())) { // Comparación sin distinguir mayúsculas/minúsculas
                throw new Exception("Error: Ya existe una empresa fabricante con el nombre '" + fabricante.getNombreFabricante() + "'.");
            }
        }
        listaFabricantes.add(fabricante);
        System.out.println("=====================================================");
        System.out.println("Empresa Fabricante '" + fabricante.getNombreFabricante() + "' agregada exitosamente.");
        System.out.println("=====================================================");
    }

    // R - Read: Buscar una Empresa Fabricante por su nombre
    public EmpresaFabricante buscar(String nombre) throws Exception {
        if (nombre == null || nombre.trim().isEmpty()) {
            throw new IllegalArgumentException("El nombre de búsqueda no puede ser nulo o vacío.");
        }
        for (EmpresaFabricante ef : listaFabricantes) {
            if (ef.getNombreFabricante().equalsIgnoreCase(nombre)) { // Comparación sin distinguir mayúsculas/minúsculas
                return ef;
            }
        }
        throw new Exception("Error: No se encontró ninguna empresa fabricante con el nombre '" + nombre + "'.");
    }

    // U - Update: Editar una Empresa Fabricante existente
    public void editar(EmpresaFabricante fabricanteActualizado) throws Exception {
        if (fabricanteActualizado == null) {
            throw new IllegalArgumentException("La empresa fabricante a actualizar no puede ser nula.");
        }
        boolean encontrado = false;
        for (int i = 0; i < listaFabricantes.size(); i++) {
            if (listaFabricantes.get(i).getNombreFabricante().equalsIgnoreCase(fabricanteActualizado.getNombreFabricante())) {
                // Actualiza el fabricante en la lista
                listaFabricantes.set(i, fabricanteActualizado);
                encontrado = true;
                System.out.println("=====================================================");
                System.out.println("Empresa Fabricante '" + fabricanteActualizado.getNombreFabricante() + "' actualizada exitosamente.");
                System.out.println("=====================================================");
                break;
            }
        }
        if (!encontrado) {
            throw new Exception("Error: No se encontró una empresa fabricante con el nombre '" + fabricanteActualizado.getNombreFabricante() + "' para actualizar.");
        }
    }

    // D - Delete: Eliminar una Empresa Fabricante por su nombre
    public void eliminar(String nombre) throws Exception {
        if (nombre == null || nombre.trim().isEmpty()) {
            throw new IllegalArgumentException("El nombre de eliminación no puede ser nulo o vacío.");
        }
        EmpresaFabricante fabricanteAEliminar = null;
        for (EmpresaFabricante ef : listaFabricantes) {
            if (ef.getNombreFabricante().equalsIgnoreCase(nombre)) {
                fabricanteAEliminar = ef;
                break;
            }
        }

        if (fabricanteAEliminar != null) {
            listaFabricantes.remove(fabricanteAEliminar);
            System.out.println("=====================================================");
            System.out.println("Empresa Fabricante '" + nombre + "' eliminada exitosamente. Nuevo número de fabricantes: " + contar());
            System.out.println("=====================================================");
        } else {
            throw new Exception("Error: No se encontró ninguna empresa fabricante con el nombre '" + nombre + "' para eliminar.");
        }
    }

    // R - Read: Listar todas las Empresas Fabricantes
    public ArrayList<EmpresaFabricante> listarTodo() throws Exception {
        if (listaFabricantes.isEmpty()) {
            throw new Exception("No hay Empresas Fabricantes en la lista.");
        }
        return new ArrayList<>(listaFabricantes); // Retorna una copia
    }

    // Contar el número de Empresas Fabricantes
    public Integer contar() {
        return listaFabricantes.size();
    }
}