
package co.edu.udc.poo.bellabotello.tiendaDeInformatica.Modelo.entidades;




public class Impresora extends Producto {
    private String velocidadImpresion;
    private ServicioTecnico servicioImpresora;
    
    public Impresora(String codigo, String modelo, String velocidadImpresion) {
        super(codigo, modelo);
        this.velocidadImpresion = velocidadImpresion;
        
       
    }
    
    
    public void setVelocidadImpresion (String velocidadImpresion) {
        this.velocidadImpresion = velocidadImpresion;
    }
    
    public void setServicioImpresora(ServicioTecnico ServicioTecnico) {
    this.servicioImpresora = ServicioTecnico;
    }
    
    public ServicioTecnico getServicioImpresora() {
        return servicioImpresora;
    }
    
    @Override
    public void mostrarInformacion() {
        System.out.printf("%-25s: %s\n", "Codigo", super.getCodigo());
        System.out.printf("%-25s: %s\n", "Modelo", super.getModelo());
        System.out.printf("%-25s: %s\n", "Velocidad de impresion", velocidadImpresion);
            if(servicioImpresora !=null){
                System.out.println("---ESTE PRODUCTO TIENE SERVICIO TECNICO---.");
           
        }
    }
}
