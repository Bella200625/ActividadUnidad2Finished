// co.edu.udc.poo.bellabotello.tiendaDeInformatica.Modelo.crud/SoporteTecnicoFabricanteCrud.java
package co.edu.udc.poo.bellabotello.tiendaDeInformatica.Modelo.crud;

import co.edu.udc.poo.bellabotello.tiendaDeInformatica.Modelo.entidades.SoporteTecnicoFabricante;
import java.util.ArrayList;
import java.util.List;

public class SoporteTecnicoFabricanteCrud {

    private List<SoporteTecnicoFabricante> listaSoportesFabricante;

    public SoporteTecnicoFabricanteCrud() {
        this.listaSoportesFabricante = new ArrayList<>();
    }

    // C - Create: Agregar un nuevo Soporte Técnico a Fabricante
    public void agregar(SoporteTecnicoFabricante soporte) throws Exception {
        if (soporte == null) {
            throw new IllegalArgumentException("El soporte técnico a fabricante a agregar no puede ser nulo.");
        }
        // Validar que el ID no sea nulo/vacío antes de intentar buscar
        if (soporte.getIdSoporte() == null || soporte.getIdSoporte().trim().isEmpty()) {
            throw new IllegalArgumentException("El ID del soporte no puede ser nulo o vacío.");
        }

        // Verificamos si ya existe un soporte con el mismo ID
        for (SoporteTecnicoFabricante stf : listaSoportesFabricante) {
            if (stf.getIdSoporte().equals(soporte.getIdSoporte())) {
                throw new Exception("Error: Ya existe un soporte técnico a fabricante con el ID '" + soporte.getIdSoporte() + "'.");
            }
        }
        
        // =========================================================================================
        // CORRECCIÓN: Elimina la línea incorrecta o cámbiala por una validación de nulidad si es lo que necesitas.
        // Si tu intención era validar que la EmpresaFabricante asociada no sea nula:
        if (soporte.getEmpresa() == null) {
            throw new IllegalArgumentException("El soporte técnico debe estar asociado a una EmpresaFabricante válida.");
        }
        // =========================================================================================

        listaSoportesFabricante.add(soporte);
        System.out.println("Soporte Técnico a Fabricante con ID '" + soporte.getIdSoporte() + "' agregado exitosamente.");
    }

    // R - Read: Buscar un Soporte Técnico a Fabricante por su ID
    public SoporteTecnicoFabricante buscar(String id) throws Exception {
        if (id == null || id.trim().isEmpty()) {
            throw new IllegalArgumentException("El ID de búsqueda no puede ser nulo o vacío.");
        }
        for (SoporteTecnicoFabricante stf : listaSoportesFabricante) {
            if (stf.getIdSoporte().equals(id)) {
                return stf;
            }
        }
        throw new Exception("Error: No se encontró ningún soporte técnico a fabricante con el ID '" + id + "'.");
    }

    // U - Update: Actualizar un Soporte Técnico a Fabricante existente
    public void editar(SoporteTecnicoFabricante soporteActualizado) throws Exception {
        if (soporteActualizado == null) {
            throw new IllegalArgumentException("El soporte técnico a fabricante a actualizar no puede ser nulo.");
        }
        // Validar que el ID no sea nulo/vacío
        if (soporteActualizado.getIdSoporte() == null || soporteActualizado.getIdSoporte().trim().isEmpty()) {
            throw new IllegalArgumentException("El ID del soporte actualizado no puede ser nulo o vacío.");
        }

        boolean encontrado = false;
        for (int i = 0; i < listaSoportesFabricante.size(); i++) {
            if (listaSoportesFabricante.get(i).getIdSoporte().equals(soporteActualizado.getIdSoporte())) {
                listaSoportesFabricante.set(i, soporteActualizado);
                encontrado = true;
                System.out.println("Soporte Técnico a Fabricante con ID '" + soporteActualizado.getIdSoporte() + "' editado exitosamente.");
                break;
            }
        }
        if (!encontrado) {
            throw new Exception("Error: No se encontró ningún soporte técnico a fabricante con el ID '" + soporteActualizado.getIdSoporte() + "' para actualizar.");
        }
    }

    // D - Delete: Eliminar un Soporte Técnico a Fabricante por su ID
    public void eliminar(String id) throws Exception {
        if (id == null || id.trim().isEmpty()) {
            throw new IllegalArgumentException("El ID de eliminación no puede ser nulo o vacío.");
        }
        SoporteTecnicoFabricante soporteAEliminar = null;
        for (SoporteTecnicoFabricante stf : listaSoportesFabricante) {
            if (stf.getIdSoporte().equals(id)) {
                soporteAEliminar = stf;
                break;
            }
        }

        if (soporteAEliminar != null) {
            listaSoportesFabricante.remove(soporteAEliminar);
            System.out.println("Soporte Técnico a Fabricante con ID '" + id + "' eliminado exitosamente. Nuevo número de soportes: " + contar());
        } else {
            throw new Exception("Error: No se encontró ningún soporte técnico a fabricante con el ID '" + id + "' para eliminar.");
        }
    }

    // R - Read: Listar todos los Soportes Técnicos a Fabricante
    public ArrayList<SoporteTecnicoFabricante> listarTodo() throws Exception {
        if (listaSoportesFabricante.isEmpty()) {
            throw new Exception("No hay Soportes Técnicos a Fabricante en la lista.");
        }
        return new ArrayList<>(listaSoportesFabricante); // Retorna una copia
    }

    // Contar el número de Soportes Técnicos a Fabricante
    public Integer contar() {
        return listaSoportesFabricante.size();
    }
}

//package co.edu.udc.poo.bellabotello.tiendaDeInformatica.Modelo.crud;
//
//import co.edu.udc.poo.bellabotello.tiendaDeInformatica.Modelo.entidades.SoporteTecnicoFabricante; // Importa la clase
//import java.util.ArrayList;
//import java.util.List;
//
//public class SoporteTecnicoFabricanteCrud {
//
//    private List<SoporteTecnicoFabricante> listaSoportesFabricante;
//
//    public SoporteTecnicoFabricanteCrud() {
//        this.listaSoportesFabricante = new ArrayList<>();
//    }
//
//    // C - Create: Agregar un nuevo Soporte Técnico a Fabricante
//    public void agregar(SoporteTecnicoFabricante soporte) throws Exception {
//        if (soporte == null) {
//            throw new IllegalArgumentException("El soporte técnico a fabricante a agregar no puede ser nulo.");
//        }
//        // Verificamos si ya existe un soporte con el mismo ID
//        for (SoporteTecnicoFabricante stf : listaSoportesFabricante) {
//            if (stf.getIdSoporte().equals(soporte.getIdSoporte())) {
//                throw new Exception("Error: Ya existe un soporte técnico a fabricante con el ID '" + soporte.getIdSoporte() + "'.");
//            }
//        }
//        listaSoportesFabricante.add(soporte);
//        System.out.println("Soporte Técnico a Fabricante con ID '" + soporte.getIdSoporte() + "' agregado exitosamente.");
//    }
//
//    // R - Read: Buscar un Soporte Técnico a Fabricante por su ID
//    public SoporteTecnicoFabricante buscar(String id) throws Exception {
//        if (id == null || id.trim().isEmpty()) {
//            throw new IllegalArgumentException("El ID de búsqueda no puede ser nulo o vacío.");
//        }
//        for (SoporteTecnicoFabricante stf : listaSoportesFabricante) {
//            if (stf.getIdSoporte().equals(id)) {
//                return stf;
//            }
//        }
//        throw new Exception("Error: No se encontró ningún soporte técnico a fabricante con el ID '" + id + "'.");
//    }
//
//    // U - Update: Editar un Soporte Técnico a Fabricante existente
//    public void editar(SoporteTecnicoFabricante soporteActualizado) throws Exception {
//        if (soporteActualizado == null) {
//            throw new IllegalArgumentException("El soporte técnico a fabricante a actualizar no puede ser nulo.");
//        }
//        boolean encontrado = false;
//        for (int i = 0; i < listaSoportesFabricante.size(); i++) {
//            if (listaSoportesFabricante.get(i).getIdSoporte().equals(soporteActualizado.getIdSoporte())) {
//                // Actualiza el soporte en la lista
//                listaSoportesFabricante.set(i, soporteActualizado);
//                encontrado = true;
//                System.out.println("Soporte Técnico a Fabricante con ID '" + soporteActualizado.getIdSoporte() + "' actualizado exitosamente.");
//                break;
//            }
//        }
//        if (!encontrado) {
//            throw new Exception("Error: No se encontró un soporte técnico a fabricante con el ID '" + soporteActualizado.getIdSoporte() + "' para actualizar.");
//        }
//    }
//
//    // D - Delete: Eliminar un Soporte Técnico a Fabricante por su ID
//    public void eliminar(String id) throws Exception {
//        if (id == null || id.trim().isEmpty()) {
//            throw new IllegalArgumentException("El ID de eliminación no puede ser nulo o vacío.");
//        }
//        SoporteTecnicoFabricante soporteAEliminar = null;
//        for (SoporteTecnicoFabricante stf : listaSoportesFabricante) {
//            if (stf.getIdSoporte().equals(id)) {
//                soporteAEliminar = stf;
//                break;
//            }
//        }
//
//        if (soporteAEliminar != null) {
//            listaSoportesFabricante.remove(soporteAEliminar);
//            System.out.println("Soporte Técnico a Fabricante con ID '" + id + "' eliminado exitosamente. Nuevo número de soportes: " + contar());
//        } else {
//            throw new Exception("Error: No se encontró ningún soporte técnico a fabricante con el ID '" + id + "' para eliminar.");
//        }
//    }
//
//    // R - Read: Listar todos los Soportes Técnicos a Fabricante
//    public ArrayList<SoporteTecnicoFabricante> listarTodo() throws Exception {
//        if (listaSoportesFabricante.isEmpty()) {
//            throw new Exception("No hay Soportes Técnicos a Fabricante en la lista.");
//        }
//        return new ArrayList<>(listaSoportesFabricante); // Retorna una copia
//    }
//
//    // Contar el número de Soportes Técnicos a Fabricante
//    public Integer contar() {
//        return listaSoportesFabricante.size();
//    }
//}