
package co.edu.udc.poo.bellabotello.tiendaDeInformatica.Modelo.entidades;
import java.util.Date;

public class PrecioServicioTecnico {
    private String id;
    private double precio;
    private Date fechaAplicacion;

    public PrecioServicioTecnico(String id, double precio, Date fechaAplicacion) {
        this.id = id;
        this.precio = precio;
        this.fechaAplicacion = fechaAplicacion;
    }
    
    public void setPrecio(double precio){
        this.precio = precio;
    }
    
    public void setFechaAplicacion(Date fechaAplicacion) {
        this.fechaAplicacion = fechaAplicacion;
    }
    
    public double getPrecio(){
        return precio;
    }
    
    public String getIdPrecio(){
        return id;
    }
    
    public void mostrarInformacion() {
        System.out.printf("%-25s: %s\n", "id", id);
        System.out.printf("%-25s: %s\n", "Precio", precio);
        System.out.printf("%-25s: %s\n", "Fecha de Aplicacion", fechaAplicacion);

}
}
