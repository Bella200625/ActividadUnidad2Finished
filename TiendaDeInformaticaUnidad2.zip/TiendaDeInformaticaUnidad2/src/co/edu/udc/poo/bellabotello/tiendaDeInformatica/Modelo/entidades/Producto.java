package co.edu.udc.poo.bellabotello.tiendaDeInformatica.Modelo.entidades;

//Clase abstracta
public abstract class Producto {
    //Atributos
    private String codigo;
    private String modelo;
    
    //Contructor, cuando creemos uno objeto, en este caso no sera asi, ya que no
    //Crearemos objetos directamente de Producto, dado que es una clase Abstracta
    public Producto(String codigo, String modelo) {
        //Asignamos los atributos al constructor
        this.codigo = codigo;
        this.modelo = modelo;
    }
    //Usamos GET para que esta clase de permiso a otras para que utilizen sus atributos
    //codigo y modelo
    public String getCodigo(){
    return codigo;
}
    public String getModelo(){
    return modelo;
    }
    
    //Metodo para mostrar informacion de esta clase, aunque no crearemos ningun producto
    //ya que esta es una clase Abstracta
    
    public abstract void mostrarInformacion();
    
    
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Producto producto = (Producto) o;
        return codigo.equals(producto.codigo);
    
    }
}
