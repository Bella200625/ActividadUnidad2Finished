package co.edu.udc.poo.bellabotello.tiendaDeInformatica.Modelo.entidades;


public class OtroProducto extends Producto {
    private String tipoProducto;
    
    
    public OtroProducto(String codigo, String tipoProducto, String modelo) {
        super(codigo, modelo);
        this.tipoProducto = tipoProducto;
    }
    
    
    public void setTipoProducto (String tipoProducto) {
        this.tipoProducto = tipoProducto;
    }
    
    //public String

    @Override
    public void mostrarInformacion() {
        System.out.printf("%-25s: %s\n", "Codigo", super.getCodigo());
        System.out.printf("%-25s: %s\n", "Producto", tipoProducto);
        System.out.printf("%-25s: %s\n", "Modelo", super.getModelo());
    }
}
