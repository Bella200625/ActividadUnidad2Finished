
package co.edu.udc.poo.bellabotello.tiendaDeInformatica.Modelo.entidades;


import java.util.Date;

public class ServicioTecnico {
    private String id;
    private String detalleServicio;
    private Date fecha;
    private PrecioServicioTecnico precioAplicado;
    private ClienteImpresora clienteImp;
    private Impresora impresora;

    public ServicioTecnico(String id, String detalleServicio, Date fecha, PrecioServicioTecnico precioAplicado, ClienteImpresora clienteImp, Impresora impresora) {
        this.id = id;
        this.detalleServicio = detalleServicio;
        this.fecha = fecha;
        this.precioAplicado = precioAplicado;
        this.clienteImp = clienteImp;
        this.impresora = impresora;
    }
    
    public void setCliente(ClienteImpresora clienteImp) {
        this.clienteImp = clienteImp;
    }
    
    public void setImpresora(Impresora impresora) {
        this.impresora = impresora;
    }
    
    public void setPrecio (PrecioServicioTecnico precioAplicado) {
        this.precioAplicado = precioAplicado;
    }
    
    public String getIdServicio() {
        return id;
    }
    
    public String getDetalleServicio(){
        return detalleServicio;
    }

    public void setDetalleServicio(String detalleServicio) {
        this.detalleServicio = detalleServicio;
    }
    
    public void mostrarInformacion() {
        System.out.printf("%-25s: %s\n", "id", id);
        System.out.printf("%-25s: %s\n", "Detalle de servicio", detalleServicio);
        System.out.printf("%-25s: %s\n", "Fecha", fecha);
        System.out.printf("%-25s: %s\n", "Precio del servicio", precioAplicado.getPrecio());
        System.out.printf("%-25s: %s\n", "Cliente", clienteImp.getId());
        System.out.printf("%-25s: %s\n", "Impresora", impresora.getCodigo());
    }
    
}