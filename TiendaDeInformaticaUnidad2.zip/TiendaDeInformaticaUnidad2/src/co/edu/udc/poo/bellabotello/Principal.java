package co.edu.udc.poo.bellabotello;
//Importamos util date, ya que utilizaremos fechas.
import java.util.Date;
import java.util.List;
import java.util.Calendar;

//Se necesito importar las clases por medio de sus rutas, porque no las encontraba o reconocia.
import co.edu.udc.poo.bellabotello.tiendaDeInformatica.Modelo.entidades.EmpresaFabricante;
import co.edu.udc.poo.bellabotello.tiendaDeInformatica.Modelo.entidades.ProductoAltaTecnologia;
import co.edu.udc.poo.bellabotello.tiendaDeInformatica.Modelo.entidades.CPU;
import co.edu.udc.poo.bellabotello.tiendaDeInformatica.Modelo.entidades.ProductoAlquiler;
import co.edu.udc.poo.bellabotello.tiendaDeInformatica.Modelo.entidades.Monitor;
import co.edu.udc.poo.bellabotello.tiendaDeInformatica.Modelo.entidades.DiscoDuro;
import co.edu.udc.poo.bellabotello.tiendaDeInformatica.Modelo.entidades.OtroProducto;
import co.edu.udc.poo.bellabotello.tiendaDeInformatica.Modelo.entidades.ClienteImpresora;
import co.edu.udc.poo.bellabotello.tiendaDeInformatica.Modelo.entidades.Impresora;
import co.edu.udc.poo.bellabotello.tiendaDeInformatica.Modelo.entidades.PrecioServicioTecnico;
import co.edu.udc.poo.bellabotello.tiendaDeInformatica.Modelo.entidades.ServicioTecnico;
import co.edu.udc.poo.bellabotello.tiendaDeInformatica.Modelo.entidades.Proveedor;
import co.edu.udc.poo.bellabotello.tiendaDeInformatica.Modelo.entidades.ProductoProveedor;
import co.edu.udc.poo.bellabotello.tiendaDeInformatica.Modelo.entidades.Cliente;
import co.edu.udc.poo.bellabotello.tiendaDeInformatica.Modelo.entidades.SoporteTecnicoFabricante;

import co.edu.udc.poo.bellabotello.tiendaDeInformatica.Modelo.crud.ProductoCrud;
import co.edu.udc.poo.bellabotello.tiendaDeInformatica.Modelo.crud.EmpresaFabricanteCrud;
import co.edu.udc.poo.bellabotello.tiendaDeInformatica.Modelo.crud.ProductoAltaTecnologiaCrud;
import co.edu.udc.poo.bellabotello.tiendaDeInformatica.Modelo.crud.CPUCrud;
import co.edu.udc.poo.bellabotello.tiendaDeInformatica.Modelo.crud.ProductoAlquilerCrud;
import co.edu.udc.poo.bellabotello.tiendaDeInformatica.Modelo.crud.MonitorCrud;
import co.edu.udc.poo.bellabotello.tiendaDeInformatica.Modelo.crud.DiscoDuroCrud;
import co.edu.udc.poo.bellabotello.tiendaDeInformatica.Modelo.crud.OtroProductoCrud;
import co.edu.udc.poo.bellabotello.tiendaDeInformatica.Modelo.crud.ClienteImpresoraCrud;
import co.edu.udc.poo.bellabotello.tiendaDeInformatica.Modelo.crud.ImpresoraCrud;
import co.edu.udc.poo.bellabotello.tiendaDeInformatica.Modelo.crud.PrecioServicioTecnicoCrud;
import co.edu.udc.poo.bellabotello.tiendaDeInformatica.Modelo.crud.ServicioTecnicoCrud;
import co.edu.udc.poo.bellabotello.tiendaDeInformatica.Modelo.crud.ProveedorCrud;
import co.edu.udc.poo.bellabotello.tiendaDeInformatica.Modelo.crud.ProductoProveedorCrud;
import co.edu.udc.poo.bellabotello.tiendaDeInformatica.Modelo.crud.SoporteTecnicoFabricanteCrud;
import co.edu.udc.poo.bellabotello.tiendaDeInformatica.Modelo.crud.ClienteCrud;


public class Principal {

    public static void main(String[] args) {
        
        //Instanciamos los Archivos Crud
        CPUCrud cpuCrud = new CPUCrud();
        ClienteImpresoraCrud clienteImpresoraCrud = new ClienteImpresoraCrud();
        DiscoDuroCrud discoDuroCrud = new DiscoDuroCrud();
        EmpresaFabricanteCrud empresaFabricanteCrud = new EmpresaFabricanteCrud();
        ImpresoraCrud impresoraCrud = new ImpresoraCrud();
        MonitorCrud monitorCrud = new MonitorCrud();
        OtroProductoCrud otroProductoCrud = new OtroProductoCrud();
        PrecioServicioTecnicoCrud precioSTCrud = new PrecioServicioTecnicoCrud();
        ProductoAlquilerCrud productoAlquilerCrud = new ProductoAlquilerCrud();
        ProductoAltaTecnologiaCrud productoATCrud = new ProductoAltaTecnologiaCrud();
        ProductoCrud producto = new ProductoCrud();
        ProductoProveedorCrud productoProveedorCrud = new ProductoProveedorCrud();
        ProveedorCrud proveedorCrud = new ProveedorCrud();
        ServicioTecnicoCrud servicioTecnicoCrud = new ServicioTecnicoCrud();
        SoporteTecnicoFabricanteCrud soporteTecnicoFabricanteCrud = new SoporteTecnicoFabricanteCrud();
        ClienteCrud clienteCrud = new ClienteCrud();


//    ========================================================================
//    Esto es una prueba para para ver ocmo poner un objeto en alta tecnologia
//    ========================================================================

        
//        EmpresaFabricante fabricanteIntelCPU = new EmpresaFabricante("Intel", "2200 Mission College Blvd. Santa clara, CA 95054, Estados Unidos", 1000);
//        EmpresaFabricante fabricanteAmdCPU = new EmpresaFabricante("AMD", "2485 Augustine Drive, Santa clara, CA 95054, Estados Unidos", 1500);
//        Date fechaFabricacionIntel = new Date();
//        Date fechaFabricacionAMD = new Date();
//        ProductoAltaTecnologia altaTecnologiaIntelCPU = new ProductoAltaTecnologia("INTEL000x1", "Estados Unidos", fechaFabricacionIntel, fabricanteIntelCPU);
//        ProductoAltaTecnologia altaTecnologiaAmdCPU = new ProductoAltaTecnologia("AMD000x2", "Estados Unidos", fechaFabricacionAMD, fabricanteAmdCPU);
        
        



//COMENZAMOS CON LAS PRUEBAS PARA VER COMO FUNCIONAN LOS CRUD's
        
        System.out.println("\n--- PRUEBAS DE Fabricante CRUD ---");
        
//CREAMOS DOS EMPRESAS, INTEL Y AMD
        try {
            //EMPRESA INTEL
            EmpresaFabricante intel = new EmpresaFabricante("Intel","Calle xx Carrera xx", "Estados Unidos", 1000);
            empresaFabricanteCrud.agregar(intel);

            
            //EMPRESA AMD
            EmpresaFabricante amd = new EmpresaFabricante("AMD","Calle xx Carrera xx", "Estados Unidos", 2000);
            empresaFabricanteCrud.agregar(amd);

            
            
            System.out.println("\nListando Fabricantes:");
            for (EmpresaFabricante fab : empresaFabricanteCrud.listarTodo()) {
                fab.mostrarInformacion();
            }
        
            intel.setDireccion("Canada"); // Actualizar país
            empresaFabricanteCrud.editar(intel);
            System.out.println("\nFabricante Intel después de editar:");
            empresaFabricanteCrud.buscar("intel").mostrarInformacion();

            empresaFabricanteCrud.eliminar("amd");
            System.out.println("\nListando Fabricantes después de eliminar AMD:");
            for (EmpresaFabricante fab : empresaFabricanteCrud.listarTodo()) {
                fab.mostrarInformacion();
            }

        } catch (Exception e) {
            System.err.println("Error en Fabricante CRUD: " + e.getMessage());
        }
        
        
        
        
        System.out.println("\n--- PRUEBAS DE CPU CRUD ---");
        try {
            CPU cpu1 = new CPU("C001", "Ryzen 7 5800X", "32GB DDR4");
            cpuCrud.agregar(cpu1);
            //cpu1.setAltaTecnologia(altaTecnologiaAmdCPU);
            

            CPU cpu2 = new CPU("C002", "Intel Core i9-12900K", "64GB DDR5");
            cpuCrud.agregar(cpu2);

            System.out.println("\nListando CPUs:");
            for (CPU cpu : cpuCrud.listarTodo()) {
                cpu.mostrarInformacion();
            }

            cpu1.setMemoriaPrincipal("16GB DDR4"); // Solo edito un campo para mostrar que se actualiza
            cpuCrud.editar(cpu1);
            System.out.println("\nCPU C001 después de editar:");
            cpuCrud.buscar("C001").mostrarInformacion();

            cpuCrud.eliminar("C002");
            System.out.println("\nListando CPUs después de eliminar C002:");
            for (CPU cpu : cpuCrud.listarTodo()) {
                cpu.mostrarInformacion();
            }

        } catch (Exception e) {
            System.err.println("Error en CPU CRUD: " + e.getMessage());
        }
        //PROBAMOS IMPRESORACRUD
        System.out.println("\n--- PRUEBAS DE DiscoDuro CRUD ---");
        try {
            DiscoDuro dd1 = new DiscoDuro("DD001", "Samsung 970 Evo", "1TB SSD");
            discoDuroCrud.agregar(dd1);

            DiscoDuro dd2 = new DiscoDuro("DD002", "Seagate Barracuda", "2TB HDD");
            discoDuroCrud.agregar(dd2);

            System.out.println("\nListando Discos Duros:");
            for (DiscoDuro dd : discoDuroCrud.listarTodo()) {
                dd.mostrarInformacion();
            }

            dd1.setCapacidadEspacio("2TB SSD");
            discoDuroCrud.editar(dd1);
            System.out.println("\nDisco Duro DD001 después de editar:");
            discoDuroCrud.buscar("DD001").mostrarInformacion();

            discoDuroCrud.eliminar("DD002");
            System.out.println("\nListando Discos Duros después de eliminar DD002:");
            for (DiscoDuro dd : discoDuroCrud.listarTodo()) {
                dd.mostrarInformacion();
            }

        } catch (Exception e) {
            System.err.println("Error en DiscoDuro CRUD: " + e.getMessage());
        }
        
        
        System.out.println("\n--- PRUEBAS DE Impresora CRUD ---");
        try {
            Impresora imp1 = new Impresora("IMP001", "Epson EcoTank L3150", "33 ppm monocromo");
            impresoraCrud.agregar(imp1);

            Impresora imp2 = new Impresora("IMP002", "HP LaserJet Pro M15w", "18 ppm");
            impresoraCrud.agregar(imp2);

            System.out.println("\nListando Impresoras:");
            for (Impresora imp : impresoraCrud.listarTodo()) {
                imp.mostrarInformacion();
            }

            imp1.setVelocidadImpresion("40 ppm monocromo");
            impresoraCrud.editar(imp1);
            System.out.println("\nImpresora IMP001 después de editar:");
            impresoraCrud.buscar("IMP001").mostrarInformacion();

            impresoraCrud.eliminar("IMP002");
            System.out.println("\nListando Impresoras después de eliminar IMP002:");
            for (Impresora imp : impresoraCrud.listarTodo()) {
                imp.mostrarInformacion();
            }

        } catch (Exception e) {
            System.err.println("Error en Impresora CRUD: " + e.getMessage());
        }
        
        
        System.out.println("\n--- PRUEBAS DE Monitor CRUD ---");
        try {
            Monitor mon1 = new Monitor("MON001", "Dell UltraSharp U2721DE", "2560x1440");
            monitorCrud.agregar(mon1);

            Monitor mon2 = new Monitor("MON002", "LG 27GN800-B", "1920x1080");
            monitorCrud.agregar(mon2);

            System.out.println("\nListando Monitores:");
            for (Monitor mon : monitorCrud.listarTodo()) {
                mon.mostrarInformacion();
            }

            mon1.setResolucionMaxima("3840x2160");
            monitorCrud.editar(mon1);
            System.out.println("\nMonitor MON001 después de editar:");
            monitorCrud.buscar("MON001").mostrarInformacion();

            monitorCrud.eliminar("MON002");
            System.out.println("\nListando Monitores después de eliminar MON002:");
            for (Monitor mon : monitorCrud.listarTodo()) {
                mon.mostrarInformacion();
            }

        } catch (Exception e) {
            System.err.println("Error en Monitor CRUD: " + e.getMessage());
        }
        
        
        System.out.println("\n--- PRUEBAS DE OtroProducto CRUD ---");
        try {
            OtroProducto op1 = new OtroProducto("OP001", "Teclado Mecánico Redragon K552", "Periférico de entrada");
            otroProductoCrud.agregar(op1);

            OtroProducto op2 = new OtroProducto("OP002", "Mouse Gamer Logitech G203", "Periférico de entrada");
            otroProductoCrud.agregar(op2);

            System.out.println("\nListando Otros Productos:");
            for (OtroProducto op : otroProductoCrud.listarTodo()) {
                op.mostrarInformacion();
            }

            op1.setTipoProducto("Teclado");
            otroProductoCrud.editar(op1);
            System.out.println("\nOtroProducto OP001 después de editar:");
            otroProductoCrud.buscar("OP001").mostrarInformacion();

            otroProductoCrud.eliminar("OP002");
            System.out.println("\nListando Otros Productos después de eliminar OP002:");
            for (OtroProducto op : otroProductoCrud.listarTodo()) {
                op.mostrarInformacion();
            }

        } catch (Exception e) {
            System.err.println("Error en OtroProducto CRUD: " + e.getMessage());
        }
        
        try {
            Cliente cli1 = new Cliente("CT001", "Juan Perez","10001", "juan.perez@example.com","302-xxx-xxxx", "Calle Falsa 123");
            clienteCrud.agregar(cli1);

            Cliente cli2 = new Cliente("CT002", "Maria Lopez","10002", "maria.lopez@example.com","301-xxx-xxxx", "Avenida Siempre Viva 456");
            clienteCrud.agregar(cli2);

            System.out.println("\nListando Clientes:");
            for (Cliente cli : clienteCrud.listarTodo()) {
                cli.mostrarInformacion();
            }

            cli1.setDireccion("Carrera 7 #1-23");
            clienteCrud.editar(cli1);
            System.out.println("\nCliente CT001 después de editar:");
            clienteCrud.buscar("CT001").mostrarInformacion();

            clienteCrud.eliminar("CT002");
            System.out.println("\nListando Clientes después de eliminar 10002:");
            for (Cliente cli : clienteCrud.listarTodo()) {
                cli.mostrarInformacion();
            }

        } catch (Exception e) {
            System.err.println("Error en Cliente CRUD: " + e.getMessage());
        }
        
        
        System.out.println("\n--- PRUEBAS DE ClienteImpresora CRUD ---");
        try {
            // Necesitamos crear un Cliente y una Impresora para asociar
            Cliente cli3 = new Cliente("CT003", "Alvaro Perez","1002247323", "alvarop@example.com","305-xxx-xxxx", "Calle 10 #20-30");
            clienteCrud.agregar(cli3);
            Impresora tempImpresora = new Impresora("PRINTER001", "Canon Pixma", "15 ppm");
            impresoraCrud.agregar(tempImpresora);

            ClienteImpresora cliImp1 = new ClienteImpresora("CI001", "Bella Botello", "1001476328", "bellabotello@example.com", "305-xxx-xxxx", "calle xx, carrera xx", tempImpresora);
            clienteImpresoraCrud.agregar(cliImp1);

            System.out.println("\nListando ClienteImpresoras:");
            for (ClienteImpresora ci : clienteImpresoraCrud.listarTodo()) {
                ci.mostrarInformacion();
            }

            // Editar (solo se puede editar el ID, pero en un caso real se editarían atributos del producto o cliente)
            // Por simplicidad, no se edita nada aquí ya que los atributos son relaciones.
            // Si ClienteImpresora tuviera atributos propios, se editarían.

            clienteImpresoraCrud.eliminar("CI001");
            System.out.println("\nListando ClienteImpresoras después de eliminar CI001:");
            // Esto debería lanzar una excepción si no hay más elementos
            try {
                clienteImpresoraCrud.listarTodo();
            } catch (Exception e) {
                System.err.println("Error al listar (esperado): " + e.getMessage());
            }

        } catch (Exception e) {
            System.err.println("Error en ClienteImpresora CRUD: " + e.getMessage());
        }
        
                // ====================================================================
        // PrecioServicioTecnico CRUD
        // ====================================================================
        System.out.println("\n--- PRUEBAS DE PrecioServicioTecnico CRUD ---");
        try {
            Calendar cal = Calendar.getInstance();
            cal.set(2025, Calendar.FEBRUARY, 12);
            PrecioServicioTecnico pst1 = new PrecioServicioTecnico("PST-001", 40000, cal.getTime());
            precioSTCrud.agregar(pst1);

            cal.set(2025, Calendar.MAY, 19);
            PrecioServicioTecnico pst2 = new PrecioServicioTecnico("PST-002", 60000, cal.getTime());
            precioSTCrud.agregar(pst2);

            System.out.println("\nListando Precios de Servicio Técnico:");
            for (PrecioServicioTecnico pst : precioSTCrud.listarTodo()) {
                pst.mostrarInformacion();
            }

            cal.set(2025, Calendar.JANUARY, 15);
            pst1.setPrecio(80000);
            pst1.setFechaAplicacion(cal.getTime());                 
            precioSTCrud.editar(pst1);
            System.out.println("\nPrecio PST-001 después de editar:");
            precioSTCrud.buscar("PST-001").mostrarInformacion();
            precioSTCrud.buscar("PST-002").mostrarInformacion();

            precioSTCrud.eliminar("PST-002");
            System.out.println("\nListando Precios de Servicio Técnico después de eliminar PST-002:");
            try {
                for (PrecioServicioTecnico pst : precioSTCrud.listarTodo()) {
                    pst.mostrarInformacion();
                }
            } catch (Exception e) {
                System.err.println("Error al listar (esperado): " + e.getMessage());
            }

        } catch (Exception e) {
            System.err.println("Error en PrecioServicioTecnico CRUD: " + e.getMessage());
        }

         System.out.println("\n--- PRUEBAS DE ProductoAlquiler CRUD ---");
        try {
            Calendar calInicioAlq001 = Calendar.getInstance();
            Calendar calFinAlq001 = Calendar.getInstance();
            Calendar calInicioAlq002 = Calendar.getInstance();
            Calendar calFinAlq002 = Calendar.getInstance();

            calInicioAlq001.set(2025, Calendar.MAY, 1);
            calFinAlq001.set(2025, Calendar.MAY, 15);
            ProductoAlquiler pa1 = new ProductoAlquiler("ALQ-001",10000, calInicioAlq001.getTime(), calFinAlq001.getTime());
            productoAlquilerCrud.agregar(pa1);

            calInicioAlq002.set(2025, Calendar.JUNE, 5);
            calFinAlq002.set(2025, Calendar.JUNE, 30);
            ProductoAlquiler pa2 = new ProductoAlquiler("ALQ-002",20000, calInicioAlq002.getTime(), calFinAlq002.getTime());
            productoAlquilerCrud.agregar(pa2);

            System.out.println("\nListando Productos en Alquiler:");
            for (ProductoAlquiler pa : productoAlquilerCrud.listarTodo()) {
                pa.mostrarInformacion();
            }

            calFinAlq001.set(2025, Calendar.MAY, 20);
            pa1.setFechaFinAlquiler(calFinAlq001.getTime());
            productoAlquilerCrud.editar(pa1);
            System.out.println("\nProducto en Alquiler ALQ-001 después de editar:");
            productoAlquilerCrud.buscar("ALQ-001").mostrarInformacion();
            productoAlquilerCrud.buscar("ALQ-002").mostrarInformacion();

            productoAlquilerCrud.eliminar("ALQ-002");
            //productoAlquilerCrud.eliminar("ALQ-001");
            System.out.println("\nListando Productos en Alquiler después de eliminar ALQ-002:");
            try {
                for (ProductoAlquiler pa : productoAlquilerCrud.listarTodo()) {
                    pa.mostrarInformacion();                            
                }
                

                
            
            } catch (Exception e) {
                System.err.println("Error al listar (esperado): " + e.getMessage());
            }

        } catch (Exception e) {
            System.err.println("Error en ProductoAlquiler CRUD: " + e.getMessage());
        }
        
        
        
        System.out.println("\n--- PRUEBAS DE ProductoAltaTecnologia CRUD ---");
        try {
            CPU cpu1 = new CPU("C001", "Ryzen 7 5800X", "32GB DDR4");
            CPU cpu2 = new CPU("C002", "Intel Core i9-12900K", "64GB DDR5");
            EmpresaFabricante intel = new EmpresaFabricante("Intel","Calle xx Carrera xx", "Estados Unidos", 1000);
            EmpresaFabricante amd = new EmpresaFabricante("AMD","Calle xx Carrera xx", "Estados Unidos", 2000);
            Calendar cal = Calendar.getInstance();
            cal.set(2023, Calendar.SEPTEMBER, 10);
            ProductoAltaTecnologia pat1 = new ProductoAltaTecnologia(cpu2, "cpu0001-001", "Estados Unidos", cal.getTime(), intel);
            productoATCrud.agregar(pat1);

            cal.set(2023, Calendar.OCTOBER, 20);
            ProductoAltaTecnologia pat2 = new ProductoAltaTecnologia(cpu1, "cpu0002-002","Estados Unidos", cal.getTime(), amd);
            productoATCrud.agregar(pat2);

            System.out.println("\nListando Productos de Alta Tecnología:");
            for (ProductoAltaTecnologia pat : productoATCrud.listarTodo()) {
                pat.mostrarInformacion();
            }

            cal.set(2024, Calendar.JANUARY, 5);
            pat1.setFechaFabricacion(cal.getTime());
            productoATCrud.editar(pat1);
            System.out.println("\nProducto de Alta Tecnología cpu0001-001 después de editar:");
            productoATCrud.buscar("cpu0001-001").mostrarInformacion();

            productoATCrud.eliminar("cpu0002-002");
            System.out.println("\nListando Productos de Alta Tecnología después de eliminar PAT-002:");
            try {
                for (ProductoAltaTecnologia pat : productoATCrud.listarTodo()) {
                    pat.mostrarInformacion();
                }
            } catch (Exception e) {
                System.err.println("Error al listar (esperado): " + e.getMessage());
            }

        } catch (Exception e) {
            System.err.println("Error en ProductoAltaTecnologia CRUD: " + e.getMessage());
        }
        
        System.out.println("\n--- PRUEBAS DE Proveedor CRUD ---");
        try {
            Proveedor prov1 = new Proveedor("Proveedor A","1000001","Calle xx Carrera xx", "Alemania");
            proveedorCrud.agregar(prov1);

            Proveedor prov2 = new Proveedor("Proveedor B","1000002","Calle xx Carrera xx", "Corea del Sur");
            proveedorCrud.agregar(prov2);

            System.out.println("\nListando Proveedores:");
            for (Proveedor prov : proveedorCrud.listarTodo()) {
                prov.mostrarInformacion();
            }

            prov1.setPaisOrigen("Estados Unidos");
            proveedorCrud.editar(prov1);
            System.out.println("\nProveedor 'Proveedor A' después de editar:");
            proveedorCrud.buscar("Proveedor A").mostrarInformacion();

            proveedorCrud.eliminar("Proveedor B");
            System.out.println("\nListando Proveedores después de eliminar 'Tech Supply B':");
            try {
                for (Proveedor prov : proveedorCrud.listarTodo()) {
                    prov.mostrarInformacion();
                }
            } catch (Exception e) {
                System.err.println("Error al listar (esperado): " + e.getMessage());
            }

        } catch (Exception e) {
            System.err.println("Error en Proveedor CRUD: " + e.getMessage());
        }
        
                System.out.println("\n--- PRUEBAS DE ProductoProveedor CRUD ---");
        try {
            // Necesitamos un Producto (usaremos un CPU ya creado) y un Proveedor
            CPU cpuParaSuministro = new CPU("CPU001", "AMD Ryzen 5", "16GB DDR4");
            Monitor monitorParaSuministro = new Monitor("monitor001", "LG", "1920x1080"); 
            cpuCrud.agregar(cpuParaSuministro); // Agregamos el CPU al CRUD de CPU para que exista
            Proveedor provParaSuministro1 = new Proveedor("Proveedor Ryzen", "PROV001", "Calle xx Carrera xx", "Colombia");
            Proveedor provParaSuministro2 = new Proveedor("Proveedor LG", "PROV002", "Calle xx Carrera xx", "España");
            proveedorCrud.agregar(provParaSuministro1); // Agregamos el Proveedor al CRUD de Proveedor
            proveedorCrud.agregar(provParaSuministro2); // Agregamos el Proveedor al CRUD de Proveedor   
            
            Calendar calCpu = Calendar.getInstance();
            calCpu.set(2025, Calendar.MARCH, 15);
            Calendar calMonitor = Calendar.getInstance();
            calMonitor.set(2025, Calendar.FEBRUARY, 8);
            ProductoProveedor pp1 = new ProductoProveedor("CPU-PROV001", calCpu.getTime(), cpuParaSuministro, provParaSuministro1, 200);
            // Si la clase ProductoProveedor tiene setProducto y setProveedor, se usarían aquí:
            // pp1.setProducto(cpuParaSuministro);
            // pp1.setProveedor(provParaSuministro);
            productoProveedorCrud.agregar(pp1);
            ProductoProveedor pp2 = new ProductoProveedor("MONITOR-PROV002", calMonitor.getTime(), monitorParaSuministro, provParaSuministro2, 500);
            productoProveedorCrud.agregar(pp2);

            System.out.println("\nListando ProductoProveedores:");
            for (ProductoProveedor pp : productoProveedorCrud.listarTodo()) {
                pp.mostrarInformacion();
            }
            pp1.setCantidadSuministrada(250);
            calCpu.set(2025, Calendar.MAY, 25);
            pp1.setFechaAdquisicion(calCpu.getTime());
            productoProveedorCrud.editar(pp1);
            System.out.println("\nProductoProveedor CPU-PROV001 después de editar:");
            productoProveedorCrud.buscar("CPU-PROV001").mostrarInformacion();

            productoProveedorCrud.eliminar("MONITOR-PROV002");
            System.out.println("\nListando ProductoProveedores después de eliminar MONITOR-PROV002:");
            for (ProductoProveedor pp : productoProveedorCrud.listarTodo()) {
                pp.mostrarInformacion();
            }

        } catch (Exception e) {
            System.err.println("Error en ProductoProveedor CRUD: " + e.getMessage());
        }
        
         System.out.println("\n--- PRUEBAS DE ServicioTecnico CRUD ---");
        try {
            Calendar cal = Calendar.getInstance();
            cal.set(2025, Calendar.MAY, 5);
            PrecioServicioTecnico pst1 = new PrecioServicioTecnico("PST-001", 40000, cal.getTime());
            Impresora imp1 = new Impresora("IMP001", "Epson EcoTank L3150", "33 ppm monocromo");
            ClienteImpresora cliImp1 = new ClienteImpresora("CI001", "Bella Botello", "1001476328", "bellabotello@example.com", "305-xxx-xxxx", "calle xx, carrera xx", imp1);
            ServicioTecnico st1 = new ServicioTecnico("SRV-001", "Cambio de cartuchos", cal.getTime(), pst1, cliImp1, imp1);
            servicioTecnicoCrud.agregar(st1);

            Calendar cal2 = Calendar.getInstance();
            cal2.set(2025, Calendar.DECEMBER, 1);
            PrecioServicioTecnico pst2 = new PrecioServicioTecnico("PST-002", 60000, cal2.getTime());
            Impresora imp2 = new Impresora("IMP002", "Epson CANON V360", "48 ppm monocromo");
            ClienteImpresora cliImp2 = new ClienteImpresora("CI002", "Alvaro Jesus", "1002247323", "aperez@example.com", "305-xxx-xxxx", "calle xx, carrera xx", imp2);
            ServicioTecnico st2 = new ServicioTecnico("SRV-002", "Cambio de torner", cal2.getTime(), pst2, cliImp2, imp2);
            servicioTecnicoCrud.agregar(st2);

            System.out.println("\nListando Servicios Técnicos:");
            for (ServicioTecnico st : servicioTecnicoCrud.listarTodo()) {
                st.mostrarInformacion();
            }
            
            PrecioServicioTecnico pst3 = new PrecioServicioTecnico("PST-002", 80000, cal2.getTime());
            st1.setPrecio(pst3);
            st1.setDetalleServicio("Cambio de tóner y revisión general");
            servicioTecnicoCrud.editar(st1);
            System.out.println("\nServicio SRV-001 después de editar:");
            servicioTecnicoCrud.buscar("SRV-001").mostrarInformacion();

            servicioTecnicoCrud.eliminar("SRV-002");
            System.out.println("\nListando Servicios Técnicos después de eliminar SRV-002:");
            try {
                for (ServicioTecnico st : servicioTecnicoCrud.listarTodo()) {
                    st.mostrarInformacion();
                }
            } catch (Exception e) {
                System.err.println("Error al listar (esperado): " + e.getMessage());
            }

        } catch (Exception e) {
            System.err.println("Error en ServicioTecnico CRUD: " + e.getMessage());
        }
        
                System.out.println("\n--- PRUEBAS DE SoporteTecnicoFabricante CRUD ---");
        try {
            // Necesitamos un Fabricante (usaremos uno ya creado o crearemos uno nuevo)
            Calendar calAlt = Calendar.getInstance();
            calAlt.set(2025, Calendar.JANUARY, 2);
            CPU cpu1 = new CPU("C001", "Ryzen 7 5800X", "32GB DDR4");
            Monitor mon1 = new Monitor("MON001", "Dell UltraSharp U2721DE", "2560x1440");
            EmpresaFabricante fabParaSoporte1 = new EmpresaFabricante("Logitech", "Calle xx Carrera xx", "Estados unidos", 4000);
            EmpresaFabricante fabParaSoporte2 = new EmpresaFabricante("LG", "Calle xx Carrera xx", "Estados unidos", 3500);
            ProductoAltaTecnologia pat1 = new ProductoAltaTecnologia(cpu1, "cpu0001-001", "Estados Unidos", calAlt.getTime(), fabParaSoporte1);
            ProductoAltaTecnologia pat2 = new ProductoAltaTecnologia(mon1, "cpu0001-001", "Estados Unidos", calAlt.getTime(), fabParaSoporte2);
            empresaFabricanteCrud.agregar(fabParaSoporte1); // Asegurarse de que el fabricante exista
            empresaFabricanteCrud.agregar(fabParaSoporte2);

            Calendar cal = Calendar.getInstance();
            cal.set(2025, Calendar.APRIL, 1);
            SoporteTecnicoFabricante stf1 = new SoporteTecnicoFabricante("STF-001", "Problemas con pines doblados", 40000, fabParaSoporte1, pat1);
            // Si la clase SoporteTecnicoFabricante tiene setFabricanteAsociado, se usaría aquí:
            stf1.setEmpresa(fabParaSoporte1);
            soporteTecnicoFabricanteCrud.agregar(stf1);

            cal.set(2025, Calendar.APRIL, 10);
            SoporteTecnicoFabricante stf2 = new SoporteTecnicoFabricante("STF-002", "Problemas con Pantalla", 80000, fabParaSoporte2, pat2);
            soporteTecnicoFabricanteCrud.agregar(stf2);

            System.out.println("\nListando Soportes Técnicos a Fabricante:");
            for (SoporteTecnicoFabricante stf : soporteTecnicoFabricanteCrud.listarTodo()) {
                stf.mostrarInformacion();
            }

            
            stf1.setDetalleSoporte("Problemas con pines doblados (investigando)");
            soporteTecnicoFabricanteCrud.editar(stf1);
            System.out.println("\nSoporte STF-001 después de editar:");
            soporteTecnicoFabricanteCrud.buscar("STF-001").mostrarInformacion();

            soporteTecnicoFabricanteCrud.eliminar("STF-002");
            System.out.println("\nListando Soportes Técnicos a Fabricante después de eliminar STF-002:");
            try {
                for (SoporteTecnicoFabricante stf : soporteTecnicoFabricanteCrud.listarTodo()) {
                    stf.mostrarInformacion();
                }
            } catch (Exception e) {
                System.err.println("Error al listar (esperado): " + e.getMessage());
            }

        } catch (Exception e) {
            System.err.println("Error en SoporteTecnicoFabricante CRUD: " + e.getMessage());
        }

        
        
    }
}      
        
        
        
        
        
        
        
        
//        //Creacion de dos empresas INTEL y AMD
//        EmpresaFabricante fabricanteIntelCPU = new EmpresaFabricante("Intel", "2200 Mission College Blvd. Santa clara, CA 95054, Estados Unidos", 1000);
//        EmpresaFabricante fabricanteAmdCPU = new EmpresaFabricante("AMD", "2485 Augustine Drive, Santa clara, CA 95054, Estados Unidos", 1500);
//        //Creamos una variable que nos de una fecha
//        Date fechaFabricacionCPU = new Date();
//        //Creamos la estructura por si el producto es de Alta Tecnologia, nos muestra lo siguente, dos en este caso, INTEL y AMD
//        ProductoAltaTecnologia altaTecnologiaIntelCPU = new ProductoAltaTecnologia("USA", fechaFabricacionCPU, fabricanteIntelCPU);
//        ProductoAltaTecnologia altaTecnologiaAmdCPU = new ProductoAltaTecnologia("USA", fechaFabricacionCPU, fabricanteAmdCPU);
//        //Creamos un Objeto con su constructor, codigo, modelo y MemoriaPrincipal en este caso
//        CPU cpu001 = new CPU("CPU001", "intel core i9", "16GB");
//        //Lo asignamos como Producto de alta tecnologia
//        cpu001.setAltaTecnologia(altaTecnologiaIntelCPU);
//        
//        //aca creamos otro objeto, pero de otro fabricante y tambien lo designamos como Alta Tecnologia
//        CPU cpu002 = new CPU("CPU002", "AMD Ryzen 5", "8GB");
//        cpu002.setAltaTecnologia(altaTecnologiaAmdCPU);
//        
//        
//        //Por ultimo Creamos uno tercer objeto, pero este no lo designamos como alta tecnologia
//        CPU cpu003 = new CPU("CPU003", "1ntel core i3", "8GB");
//        
//        
//        //Seguimos con los monitores, y en este caso, ya que los monitores pueden ser alquilados
//        // se designa de la clase alquiler, que nos muestre su constructor en caso de que asi sea.
//        ProductoAlquiler alquilerMonitor = new ProductoAlquiler(25000);
//        //Creamos el primer objeto con su constructor, Codigo, Modelo y Resolucion Maxima
//        Monitor monitor001 = new Monitor("MON001", "LG", "1920x1080");
//        //le asignamos que si se pueda alquilar
//        monitor001.setAlquiler(alquilerMonitor);
//        //Creamos un segundo objeto que no se pueda alquilar
//        Monitor monitor002 = new Monitor("MON002", "SAMSUNG", "1920x1080");
//        
//        
//        //en este objeto veremos que podremos tanto Asignar como alta tecnologia y que se pueda alquilar, haremos 3 casos
//        //Creamos un Fabricante, Kingston
//        EmpresaFabricante fabricanteHdd = new EmpresaFabricante("Kingston", "Fountain Valley, CA 92708, Estados Unidos", 800);
//        //Asignamos una fecha que se cree, en este caso solo se creara cuando el sistema se inicia de momento
//        Date fechaFabricacionHdd = new Date();
//        //Creamos la estructura por si el producto es de Alta Tecnologia
//        ProductoAltaTecnologia altaTecnologiaHdd = new ProductoAltaTecnologia("USA", fechaFabricacionHdd, fabricanteHdd);
//        //Creamos la estructura por si el producto se puede alquilar
//        ProductoAlquiler alquierHdd = new ProductoAlquiler(12000);
//        //Creamos un objeto, con su estructura, Codigo, Modelo y Capacidad
//        DiscoDuro hdd001 = new DiscoDuro("HDD001", "Kingston", "2TB");
//        //Le decimos que es de alta tecnologia
//        hdd001.setAltaTecnologia(altaTecnologiaHdd);
//        //y le decimos que tambien se puede alquilar
//        hdd001.setAlquiler(alquilerMonitor);
//        
//        //Aca solo le decimos que este segundo objeto solo sea de alta tecnologia
//        DiscoDuro hdd002 = new DiscoDuro("HDD002", "Kingston", "1TB");
//        hdd002.setAltaTecnologia(altaTecnologiaHdd);
//        
//        //En este que solo se pueda alquitar
//        DiscoDuro hdd003 = new DiscoDuro("HDD003", "Kingston", "500GB");
//        hdd003.setAlquiler(alquilerMonitor);
//        
//        //Aqui para hacer uso de la clase de OtroProducto, Creamos diferentes productos para variar
//        OtroProducto key001 = new OtroProducto("KEY001", "Teclado", "Corsair");
//        OtroProducto mouse001 = new OtroProducto("MOUSE001", "Mouse", "Logitech");
//        OtroProducto head001 = new OtroProducto("Head001", "Auriculares", "Sony");
//        
//        //Empresas Fabricantes de otros productos
//        
//        EmpresaFabricante fabricanteCorsair = new EmpresaFabricante("Corsair", "47100 Bayside Parkway, Fremont, California, Estados Unidos", 750);
//        EmpresaFabricante fabricanteLogitech = new EmpresaFabricante("Logitech", "3930 North first Street, San Jose, CA 95134, Estados Unidos", 980);
//        EmpresaFabricante fabricanteSony = new EmpresaFabricante("Sony", "25 Madison avenue, Nueva York 10010, Nueva York", 750);
//        
//        
//        
//        // Clientes impresora
//        ClienteImpresora clientePrint001 = new ClienteImpresora("Alvaro Jesus", "15896328", "001-xxx-xxx", "Calle xx, Carrera xx, Casa xx");
//        ClienteImpresora clientePrint002 = new ClienteImpresora("Bella Botello", "12598526", "002-xxx-xxx", "Calle xx, Carrera xx, Casa xx");
//        
//        
//        
//        Impresora impresora001 = new Impresora("IMP001", "CANON", "33ppm");
//        //impresora001.setServicioImpresora(ServicioTecnico);
//        Impresora impresora002 = new Impresora("IMP002", "CANON", "19ppm");
//        //impresora002.setServicioImpresora(ServicioTecnico);
//        
//        Date fechaPrecio001 = new Date();
//        PrecioServicioTecnico precio001 = new PrecioServicioTecnico(50000, fechaPrecio001);
//        Date fechaPrecio002 = new Date();
//        PrecioServicioTecnico precio002 = new PrecioServicioTecnico(35000, fechaPrecio002);
//        
//        Date fechaServicio001 = new Date();
//        ServicioTecnico servicio001 = new ServicioTecnico("Limpieza de cabezales", 40000, fechaServicio001, precio001);
//        
//        Date fechaServicio002 = new Date();
//        ServicioTecnico servicio002 = new ServicioTecnico("Reemplazo de toner", 36000, fechaServicio002, precio002);
//        
//        //Creacion de dos Proveedores
//        Proveedor proveedor001 = new Proveedor("PR000x1", "Calle xx1, Carrera xx1", "Estados Unidos");
//        Proveedor proveedor002 = new Proveedor("PR000x2", "Calle xx2, Carrera xx2", "Estados Unidos");
//        
//        //Productos creados asociados a los proovedores
//        Date fechaAdquisicion001 = new Date();
//        ProductoProveedor pp001 = new ProductoProveedor(fechaAdquisicion001, cpu001, proveedor001);
//        Date fechaAdquisicion002 = new Date();
//        ProductoProveedor pp002 = new ProductoProveedor(fechaAdquisicion002, cpu002, proveedor002);
//        Date fechaAdquisicion003 = new Date();
//        ProductoProveedor pp003 = new ProductoProveedor(fechaAdquisicion003, cpu003, proveedor001);
//        
//        
//        
//        
//        
//        //Aca Imprimeros todo por medio de los metodos que estan en las clases, Objeto.mostrarInformacion
//        
//        
//        System.out.println("||======Tienda de Informatica======||");
//        System.out.println("\n");
//        System.out.println("\n");
//        System.out.println("||======Informacion CPU======||");
//        cpu001.mostrarInformacion();
//        System.out.println("-------------------------------------------------------------");
//        cpu002.mostrarInformacion();
//        System.out.println("-------------------------------------------------------------");
//        cpu003.mostrarInformacion();
//        System.out.println("\n");
//        System.out.println("||======Informacion Monitor======||");
//        monitor001.mostrarInformacion();
//        System.out.println("-------------------------------------------------------------");
//        monitor002.mostrarInformacion();
//        System.out.println("\n");
//        System.out.println("||======Informacion Disco Duro======||");
//        hdd001.mostrarInformacion();
//        System.out.println("-------------------------------------------------------------");
//        hdd002.mostrarInformacion();
//        System.out.println("-------------------------------------------------------------");
//        hdd003.mostrarInformacion();
//        System.out.println("\n");
//        System.out.println("||======Informacion Impresora======||");
//        impresora001.mostrarInformacion();
//        System.out.println("-------------------------------------------------------------");
//        impresora002.mostrarInformacion();
//        System.out.println("\n");
//        System.out.println("||======Informacion Otros Productos======||");
//        key001.mostrarInformacion();
//        System.out.println("-------------------------------------------------------------");
//        mouse001.mostrarInformacion();
//        System.out.println("-------------------------------------------------------------");
//        head001.mostrarInformacion();
//        System.out.println("\n");
//        System.out.println("||======Servicios Tecnicos======||");
//        System.out.printf("%-25s: %s\n", "ID del Cliente", clientePrint001.getId());
//        System.out.printf("%-25s: %s\n", "Servicio a Impresora", servicio001.getDetalleServicio());
//        System.out.printf("%-25s: %s\n", "Facturado", servicio001.getDetalleFacturado());
//        System.out.println("-------------------------------------------------------------");
//        System.out.printf("%-25s: %s\n", "ID del Cliente", clientePrint002.getId());
//        System.out.printf("%-25s: %s\n", "Servicio a Impresora", servicio002.getDetalleServicio());
//        System.out.printf("%-25s: %s\n", "Facturado", servicio002.getDetalleFacturado());
//        System.out.println("\n");
//        System.out.println("||======Clientes Registrados con servicio tecnico======||");
//        clientePrint001.mostrarInformacion();
//        System.out.println("-------------------------------------------------------------");
//        clientePrint002.mostrarInformacion();
//        
//        
//        
//        System.out.println("\n");
//        System.out.println("||======Informacion Fabricantes======||");
//        fabricanteIntelCPU.mostrarInformacion();
//        System.out.println("-------------------------------------------------------------");
//        fabricanteAmdCPU.mostrarInformacion();
//        System.out.println("-------------------------------------------------------------");
//        fabricanteHdd.mostrarInformacion();
//        System.out.println("-------------------------------------------------------------");
//        fabricanteCorsair.mostrarInformacion();
//        System.out.println("-------------------------------------------------------------");
//        fabricanteLogitech.mostrarInformacion();
//        System.out.println("-------------------------------------------------------------");
//        fabricanteSony.mostrarInformacion();
//        
//        System.out.println("\n");
//        System.out.println("||======Informacion Proveedores======||");
//        proveedor001.mostrarInformacion();
//        System.out.println("-------------------------------------------------------------");
//        proveedor002.mostrarInformacion();
//        
//        System.out.println("\n");
//        System.out.println("||======Informacion Proveedores======||");
//        pp001.mostrarInformacion();
//        System.out.println("-------------------------------------------------------------");
//        pp002.mostrarInformacion();
//        System.out.println("-------------------------------------------------------------");
//        pp003.mostrarInformacion();
        
    
//    }
            
    
//}
