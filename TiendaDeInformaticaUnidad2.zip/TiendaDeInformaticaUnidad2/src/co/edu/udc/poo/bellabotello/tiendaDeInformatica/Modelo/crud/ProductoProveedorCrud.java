package co.edu.udc.poo.bellabotello.tiendaDeInformatica.Modelo.crud;

import co.edu.udc.poo.bellabotello.tiendaDeInformatica.Modelo.entidades.ProductoProveedor; // Importa la clase
import java.util.ArrayList;
import java.util.List;

public class ProductoProveedorCrud {

    private List<ProductoProveedor> listaProductoProveedores;

    public ProductoProveedorCrud() {
        this.listaProductoProveedores = new ArrayList<>();
    }

    // C - Create: Agregar una nueva relación Producto-Proveedor
    public void agregar(ProductoProveedor pp) throws Exception {
        if (pp == null) {
            throw new IllegalArgumentException("La relación producto-proveedor a agregar no puede ser nula.");
        }
        // Verificamos si ya existe una relación con el mismo ID
        for (ProductoProveedor existentePP : listaProductoProveedores) {
            if (existentePP.getIdProductoProveedor().equals(pp.getIdProductoProveedor())) {
                throw new Exception("Error: Ya existe una relación producto-proveedor con el ID '" + pp.getIdProductoProveedor() + "'.");
            }
        }
        listaProductoProveedores.add(pp);
        System.out.println("Relación Producto-Proveedor con ID '" + pp.getIdProductoProveedor() + "' agregada exitosamente.");
    }

    // R - Read: Buscar una relación Producto-Proveedor por su ID
    public ProductoProveedor buscar(String id) throws Exception {
        if (id == null || id.trim().isEmpty()) {
            throw new IllegalArgumentException("El ID de búsqueda no puede ser nulo o vacío.");
        }
        for (ProductoProveedor pp : listaProductoProveedores) {
            if (pp.getIdProductoProveedor().equals(id)) {
                return pp;
            }
        }
        throw new Exception("Error: No se encontró ninguna relación producto-proveedor con el ID '" + id + "'.");
    }

    // U - Update: Editar una relación Producto-Proveedor existente
    public void editar(ProductoProveedor ppActualizado) throws Exception {
        if (ppActualizado == null) {
            throw new IllegalArgumentException("La relación producto-proveedor a actualizar no puede ser nula.");
        }
        boolean encontrado = false;
        for (int i = 0; i < listaProductoProveedores.size(); i++) {
            if (listaProductoProveedores.get(i).getIdProductoProveedor().equals(ppActualizado.getIdProductoProveedor())) {
                // Actualiza la relación en la lista
                listaProductoProveedores.set(i, ppActualizado);
                encontrado = true;
                System.out.println("Relación Producto-Proveedor con ID '" + ppActualizado.getIdProductoProveedor() + "' actualizada exitosamente.");
                break;
            }
        }
        if (!encontrado) {
            throw new Exception("Error: No se encontró una relación producto-proveedor con el ID '" + ppActualizado.getIdProductoProveedor() + "' para actualizar.");
        }
    }

    // D - Delete: Eliminar una relación Producto-Proveedor por su ID
    public void eliminar(String id) throws Exception {
        if (id == null || id.trim().isEmpty()) {
            throw new IllegalArgumentException("El ID de eliminación no puede ser nulo o vacío.");
        }
        ProductoProveedor ppAEliminar = null;
        for (ProductoProveedor pp : listaProductoProveedores) {
            if (pp.getIdProductoProveedor().equals(id)) {
                ppAEliminar = pp;
                break;
            }
        }

        if (ppAEliminar != null) {
            listaProductoProveedores.remove(ppAEliminar);
            System.out.println("Relación Producto-Proveedor con ID '" + id + "' eliminada exitosamente. Nuevo número de relaciones: " + contar());
        } else {
            throw new Exception("Error: No se encontró ninguna relación producto-proveedor con el ID '" + id + "' para eliminar.");
        }
    }

    // R - Read: Listar todas las relaciones Producto-Proveedor
    public ArrayList<ProductoProveedor> listarTodo() throws Exception {
        if (listaProductoProveedores.isEmpty()) {
            throw new Exception("No hay relaciones Producto-Proveedor en la lista.");
        }
        return new ArrayList<>(listaProductoProveedores); // Retorna una copia
    }

    // Contar el número de relaciones Producto-Proveedor
    public Integer contar() {
        return listaProductoProveedores.size();
    }
}