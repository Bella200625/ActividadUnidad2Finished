package co.edu.udc.poo.bellabotello.tiendaDeInformatica.Modelo.crud;

import co.edu.udc.poo.bellabotello.tiendaDeInformatica.Modelo.entidades.DiscoDuro; // Importa la clase DiscoDuro
import java.util.ArrayList;
import java.util.List;

public class DiscoDuroCrud {

    private List<DiscoDuro> listaDiscosDuros; // La lista ahora es específicamente de objetos DiscoDuro

    public DiscoDuroCrud() {
        this.listaDiscosDuros = new ArrayList<>();
    }

    // C - Create: Agregar un nuevo Disco Duro
    public void agregar(DiscoDuro discoDuro) throws Exception {
        if (discoDuro == null) {
            throw new IllegalArgumentException("El disco duro a agregar no puede ser nulo.");
        }
        // Verificamos si ya existe un disco duro con el mismo código
        for (DiscoDuro dd : listaDiscosDuros) {
            if (dd.getCodigo().equals(discoDuro.getCodigo())) {
                throw new Exception("Error: Ya existe un disco duro con el código '" + discoDuro.getCodigo() + "'.");
            }
        }
        listaDiscosDuros.add(discoDuro);
        System.out.println("=====================================================");
        System.out.println("Disco Duro con código '" + discoDuro.getCodigo() + "' agregado exitosamente.");
        System.out.println("=====================================================");
    }

    // R - Read: Buscar un Disco Duro por su código
    public DiscoDuro buscar(String codigo) throws Exception { // El código de DiscoDuro es String
        if (codigo == null || codigo.trim().isEmpty()) {
            throw new IllegalArgumentException("El código de búsqueda no puede ser nulo o vacío.");
        }
        for (DiscoDuro dd : listaDiscosDuros) {
            if (dd.getCodigo().equals(codigo)) {
                return dd;
            }
        }
        throw new Exception("Error: No se encontró ningún disco duro con el código '" + codigo + "'.");
    }

    // U - Update: Editar un Disco Duro existente
    public void editar(DiscoDuro discoDuroActualizado) throws Exception {
        if (discoDuroActualizado == null) {
            throw new IllegalArgumentException("El disco duro a actualizar no puede ser nulo.");
        }
        boolean encontrado = false;
        for (int i = 0; i < listaDiscosDuros.size(); i++) {
            if (listaDiscosDuros.get(i).getCodigo().equals(discoDuroActualizado.getCodigo())) {
                // Actualiza el disco duro en la lista
                listaDiscosDuros.set(i, discoDuroActualizado);
                encontrado = true;
                System.out.println("=====================================================");
                System.out.println("Disco Duro con código '" + discoDuroActualizado.getCodigo() + "' actualizado exitosamente.");
                System.out.println("=====================================================");
                break;
            }
        }
        if (!encontrado) {
            throw new Exception("Error: No se encontró un disco duro con el código '" + discoDuroActualizado.getCodigo() + "' para actualizar.");
        }
    }

    // D - Delete: Eliminar un Disco Duro por su código
    public void eliminar(String codigo) throws Exception { // El código de DiscoDuro es String
        if (codigo == null || codigo.trim().isEmpty()) {
            throw new IllegalArgumentException("El código de eliminación no puede ser nulo o vacío.");
        }
        DiscoDuro discoDuroAEliminar = null;
        for (DiscoDuro dd : listaDiscosDuros) {
            if (dd.getCodigo().equals(codigo)) {
                discoDuroAEliminar = dd;
                break;
            }
        }

        if (discoDuroAEliminar != null) {
            listaDiscosDuros.remove(discoDuroAEliminar);
            System.out.println("=====================================================");
            System.out.println("Disco Duro con código '" + codigo + "' eliminado exitosamente. Nuevo número de Discos Duros: " + contar());
            System.out.println("=====================================================");
        } else {
            throw new Exception("Error: No se encontró ningún disco duro con el código '" + codigo + "' para eliminar.");
        }
    }

    // R - Read: Listar todos los Discos Duros
    public ArrayList<DiscoDuro> listarTodo() throws Exception {
        if (listaDiscosDuros.isEmpty()) {
            throw new Exception("No hay Discos Duros en la lista.");
        }
        return new ArrayList<>(listaDiscosDuros); // Retorna una copia
    }

    // Contar el número de Discos Duros
    public Integer contar() {
        return listaDiscosDuros.size();
    }
}