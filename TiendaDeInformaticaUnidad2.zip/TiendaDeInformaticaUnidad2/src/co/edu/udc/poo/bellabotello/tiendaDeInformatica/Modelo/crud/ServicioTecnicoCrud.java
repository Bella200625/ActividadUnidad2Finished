package co.edu.udc.poo.bellabotello.tiendaDeInformatica.Modelo.crud;

import co.edu.udc.poo.bellabotello.tiendaDeInformatica.Modelo.entidades.ServicioTecnico; // Importa la clase
import java.util.ArrayList;
import java.util.List;

public class ServicioTecnicoCrud {

    private List<ServicioTecnico> listaServiciosTecnicos;

    public ServicioTecnicoCrud() {
        this.listaServiciosTecnicos = new ArrayList<>();
    }

    // C - Create: Agregar un nuevo Servicio Técnico
    public void agregar(ServicioTecnico servicio) throws Exception {
        if (servicio == null) {
            throw new IllegalArgumentException("El servicio técnico a agregar no puede ser nulo.");
        }
        // Verificamos si ya existe un servicio con el mismo ID
        for (ServicioTecnico st : listaServiciosTecnicos) {
            if (st.getIdServicio().equals(servicio.getIdServicio())) {
                throw new Exception("Error: Ya existe un servicio técnico con el ID '" + servicio.getIdServicio() + "'.");
            }
        }
        listaServiciosTecnicos.add(servicio);
        System.out.println("Servicio Técnico con ID '" + servicio.getIdServicio() + "' agregado exitosamente.");
    }

    // R - Read: Buscar un Servicio Técnico por su ID
    public ServicioTecnico buscar(String id) throws Exception {
        if (id == null || id.trim().isEmpty()) {
            throw new IllegalArgumentException("El ID de búsqueda no puede ser nulo o vacío.");
        }
        for (ServicioTecnico st : listaServiciosTecnicos) {
            if (st.getIdServicio().equals(id)) {
                return st;
            }
        }
        throw new Exception("Error: No se encontró ningún servicio técnico con el ID '" + id + "'.");
    }

    // U - Update: Editar un Servicio Técnico existente
    public void editar(ServicioTecnico servicioActualizado) throws Exception {
        if (servicioActualizado == null) {
            throw new IllegalArgumentException("El servicio técnico a actualizar no puede ser nulo.");
        }
        boolean encontrado = false;
        for (int i = 0; i < listaServiciosTecnicos.size(); i++) {
            if (listaServiciosTecnicos.get(i).getIdServicio().equals(servicioActualizado.getIdServicio())) {
                // Actualiza el servicio en la lista
                listaServiciosTecnicos.set(i, servicioActualizado);
                encontrado = true;
                System.out.println("Servicio Técnico con ID '" + servicioActualizado.getIdServicio() + "' actualizado exitosamente.");
                break;
            }
        }
        if (!encontrado) {
            throw new Exception("Error: No se encontró un servicio técnico con el ID '" + servicioActualizado.getIdServicio() + "' para actualizar.");
        }
    }

    // D - Delete: Eliminar un Servicio Técnico por su ID
    public void eliminar(String id) throws Exception {
        if (id == null || id.trim().isEmpty()) {
            throw new IllegalArgumentException("El ID de eliminación no puede ser nulo o vacío.");
        }
        ServicioTecnico servicioAEliminar = null;
        for (ServicioTecnico st : listaServiciosTecnicos) {
            if (st.getIdServicio().equals(id)) {
                servicioAEliminar = st;
                break;
            }
        }

        if (servicioAEliminar != null) {
            listaServiciosTecnicos.remove(servicioAEliminar);
            System.out.println("Servicio Técnico con ID '" + id + "' eliminado exitosamente. Nuevo número de servicios: " + contar());
        } else {
            throw new Exception("Error: No se encontró ningún servicio técnico con el ID '" + id + "' para eliminar.");
        }
    }

    // R - Read: Listar todos los Servicios Técnicos
    public ArrayList<ServicioTecnico> listarTodo() throws Exception {
        if (listaServiciosTecnicos.isEmpty()) {
            throw new Exception("No hay Servicios Técnicos en la lista.");
        }
        return new ArrayList<>(listaServiciosTecnicos); // Retorna una copia
    }

    // Contar el número de Servicios Técnicos
    public Integer contar() {
        return listaServiciosTecnicos.size();
    }
}