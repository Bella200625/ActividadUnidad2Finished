
package co.edu.udc.poo.bellabotello.tiendaDeInformatica.Modelo.entidades;




public class Proveedor {
    private String nombreProveedor;
    private String NIF;
    private String direccion;
    private String paisOrigen;

    public Proveedor(String nombreProveedor, String NIF, String direccion, String paisOrigen) {
        this.nombreProveedor = nombreProveedor;
        this.NIF = NIF;
        this.direccion = direccion;
        this.paisOrigen = paisOrigen;
    }
    
    public void setPaisOrigen(String paisOrigen){
        this.paisOrigen = paisOrigen;
    }
    
    public String getNombreProveedor() {
        return nombreProveedor;
    }
    
    public String getNIF(){
        return NIF;
    }
    
    public void mostrarInformacion() {
        System.out.printf("%-25s: %s\n", "Proveedor", nombreProveedor);
        System.out.printf("%-25s: %s\n", "NIF", NIF);
        System.out.printf("%-25s: %s\n", "Direccion", direccion);
        System.out.printf("%-25s: %s\n", "Pais", paisOrigen);
    
    }
}