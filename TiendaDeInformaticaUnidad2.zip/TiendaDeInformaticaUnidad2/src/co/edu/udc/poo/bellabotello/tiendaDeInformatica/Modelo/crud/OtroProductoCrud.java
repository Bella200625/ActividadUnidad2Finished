package co.edu.udc.poo.bellabotello.tiendaDeInformatica.Modelo.crud;

import co.edu.udc.poo.bellabotello.tiendaDeInformatica.Modelo.entidades.OtroProducto; // Importa la clase OtroProducto
import java.util.ArrayList;
import java.util.List;

public class OtroProductoCrud {

    private List<OtroProducto> listaOtrosProductos; // La lista es de objetos OtroProducto

    public OtroProductoCrud() {
        this.listaOtrosProductos = new ArrayList<>();
    }

    // C - Create: Agregar un nuevo OtroProducto
    public void agregar(OtroProducto otroProducto) throws Exception {
        if (otroProducto == null) {
            throw new IllegalArgumentException("El producto a agregar no puede ser nulo.");
        }
        // Verificamos si ya existe un producto con el mismo código
        for (OtroProducto op : listaOtrosProductos) {
            if (op.getCodigo().equals(otroProducto.getCodigo())) {
                throw new Exception("Error: Ya existe otro producto con el código '" + otroProducto.getCodigo() + "'.");
            }
        }
        listaOtrosProductos.add(otroProducto);
        System.out.println("Otro Producto con código '" + otroProducto.getCodigo() + "' agregado exitosamente.");
    }

    // R - Read: Buscar un OtroProducto por su código
    public OtroProducto buscar(String codigo) throws Exception {
        if (codigo == null || codigo.trim().isEmpty()) {
            throw new IllegalArgumentException("El código de búsqueda no puede ser nulo o vacío.");
        }
        for (OtroProducto op : listaOtrosProductos) {
            if (op.getCodigo().equals(codigo)) {
                return op;
            }
        }
        throw new Exception("Error: No se encontró ningún otro producto con el código '" + codigo + "'.");
    }

    // U - Update: Editar un OtroProducto existente
    public void editar(OtroProducto otroProductoActualizado) throws Exception {
        if (otroProductoActualizado == null) {
            throw new IllegalArgumentException("El producto a actualizar no puede ser nulo.");
        }
        boolean encontrado = false;
        for (int i = 0; i < listaOtrosProductos.size(); i++) {
            if (listaOtrosProductos.get(i).getCodigo().equals(otroProductoActualizado.getCodigo())) {
                // Actualiza el producto en la lista
                listaOtrosProductos.set(i, otroProductoActualizado);
                encontrado = true;
                System.out.println("Otro Producto con código '" + otroProductoActualizado.getCodigo() + "' actualizado exitosamente.");
                break;
            }
        }
        if (!encontrado) {
            throw new Exception("Error: No se encontró otro producto con el código '" + otroProductoActualizado.getCodigo() + "' para actualizar.");
        }
    }

    // D - Delete: Eliminar un OtroProducto por su código
    public void eliminar(String codigo) throws Exception {
        if (codigo == null || codigo.trim().isEmpty()) {
            throw new IllegalArgumentException("El código de eliminación no puede ser nulo o vacío.");
        }
        OtroProducto otroProductoAEliminar = null;
        for (OtroProducto op : listaOtrosProductos) {
            if (op.getCodigo().equals(codigo)) {
                otroProductoAEliminar = op;
                break;
            }
        }

        if (otroProductoAEliminar != null) {
            listaOtrosProductos.remove(otroProductoAEliminar);
            System.out.println("Otro Producto con código '" + codigo + "' eliminado exitosamente. Nuevo número de Otros Productos: " + contar());
        } else {
            throw new Exception("Error: No se encontró ningún otro producto con el código '" + codigo + "' para eliminar.");
        }
    }

    // R - Read: Listar todos los Otros Productos
    public ArrayList<OtroProducto> listarTodo() throws Exception {
        if (listaOtrosProductos.isEmpty()) {
            throw new Exception("No hay Otros Productos en la lista.");
        }
        return new ArrayList<>(listaOtrosProductos); // Retorna una copia
    }

    // Contar el número de Otros Productos
    public Integer contar() {
        return listaOtrosProductos.size();
    }
}