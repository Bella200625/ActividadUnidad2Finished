
package co.edu.udc.poo.bellabotello.tiendaDeInformatica.Modelo.entidades;

import java.util.Date;


public class ProductoAlquiler {
    private String id;
    private double precioHora;
    private Date fechaInicioAlquiler;
    private Date fechaFinAlquiler;
    

    public ProductoAlquiler(String id, double precioHora, Date fechaInicioAlquiler, Date fechaFinAlquiler) {
        this.id = id;
        this.precioHora = precioHora;
        this.fechaInicioAlquiler = fechaInicioAlquiler;
        this.fechaFinAlquiler = fechaFinAlquiler;
    }

    public String getIdAlquiler() {
        return id;
    }
    
    public double getPrecioHora() {
        return precioHora;
    }
    
    public void setFechaInicioAlquiler(Date fechaInicioAlquiler){
        this.fechaInicioAlquiler = fechaInicioAlquiler;
    }
    
    public void setFechaFinAlquiler(Date fechaFinAlquiler){
        this.fechaFinAlquiler = fechaFinAlquiler;
    }    
    
    public void mostrarInformacion(){
        System.out.printf("%-25s: %s\n", "Id", id);
        System.out.printf("%-25s: %s\n", "Precio por Hora", precioHora);
        System.out.printf("%-25s: %s\n", "Alquiler inicia en", fechaInicioAlquiler);
        System.out.printf("%-25s: %s\n", "Alquiler finaliza en", fechaFinAlquiler);
    }
}